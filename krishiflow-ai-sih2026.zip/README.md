# KRISHIFLOW-AI | Smart India Hackathon 2026 (Problem ID: SIH26032)

> **Autonomous End-to-End AI-Powered Farmer Procurement & Logistics Infrastructure**

A production-ready platform built for the Smart India Hackathon 2026, featuring 5 role-based dashboards, real-time GPS fleet tracking, an 8-step offline farmer assistance wizard for PACS cooperative societies, smart vehicle allocation using Haversine distance calculations, automated digital weighbridge grading, direct PFMS DBT payments, multilingual voice assistance (English, Hindi, Odia), and full Supabase PostgreSQL integration.

---

## 🌾 Key Highlights & Innovation

1. **5 Role-Based Dashboards**:
   - 🌾 **Farmer Dashboard (`/farmer`)**: Crop registration, Self Transport vs. Free Vehicle Pickup flow, live queue position, GPS vehicle tracking, PFMS DBT settlement tracker, PDF token & payment slip generator.
   - 🏘️ **Society Officer Dashboard (`/society`)**: 8-Step Offline Farmer Inclusivity Wizard for non-smartphone farmers, physical QR token printing, live fleet radar map, society analytics.
   - 🏢 **Procurement Officer Dashboard (`/officer`)**: Mandi incharge control room, rule-based smart alerts (capacity >90%, slot congestion), live token call board with broadcast & SMS, computerized weighbridge quality grading calculator (Grade A/B/C).
   - 🚚 **Vehicle Driver App (`/driver`)**: Online/offline toggle, dispatch accept/decline, 10-second live GPS broadcasting, 7 trip progress stages, turn-by-turn OSRM navigation guidance.
   - 👨💼 **State Procurement Manager (`/manager`)**: OpenAI GPT-4 operational insights, statewide GIS mandi/vehicle radar, district procurement charts, bottleneck detection.

2. **Core Specialized Transport Decision Flow**:
   - **Self Transport**: Direct 7-day slot booking grid (30-minute intervals) $\rightarrow$ instant Token generation $\rightarrow$ QR barcode $\rightarrow$ printable PDF $\rightarrow$ automated MSG91 SMS.
   - **Request Vehicle**: Farm pickup coordinate capture $\rightarrow$ nearest available vehicle matched via Haversine formula $\rightarrow$ appointment slot locked to $\ge 2$ hours post-pickup $\rightarrow$ live GPS tracking on Leaflet map.

3. **Inclusivity for Non-Digital Farmers**:
   - 8-Step assisted wizard at Primary Agricultural Cooperative Societies (PACS).
   - Instant physical QR token slip printing via jsPDF.
   - SMS notifications routed to designated family alternate mobile numbers.

4. **Multi-Channel Real-Time Subscriptions**:
   - Live queue advancement when officers click `[Call Next Token]`.
   - Driver location broadcast every 10 seconds.
   - Instant browser toast alerts whenever SMS or notifications arrive.
   - Full notifications center with filtering (All / Unread / Logistics / DBT Payments).

---

## 🚀 Quick Start (Run Locally)

### Prerequisites
- Node.js 18+ (tested on v22)
- npm 9+

### 1. Install Dependencies
```bash
npm install
```

### 2. Launch Development Server
```bash
npm run dev
```
Open your browser at `http://localhost:3000`.

### 3. Production Build & Type Check
```bash
npx tsc --noEmit
npm run build
```

---

## 🔑 1-Click Evaluation Credentials

Use the fast-fill role cards on the **[Login Page](/login)** or sign in with:

| Role | Email | Password |
| :--- | :--- | :--- |
| **Farmer** | `farmer@krishiflow.ai` | `farmer123` |
| **Society Officer (PACS)** | `society@krishiflow.ai` | `society123` |
| **Procurement Officer** | `officer@krishiflow.ai` | `officer123` |
| **Vehicle Driver** | `driver@krishiflow.ai` | `driver123` |
| **State Manager (IAS)** | `manager@krishiflow.ai` | `manager123` |

---

## 🗄️ Database Architecture (18 Tables)

Located in `supabase/migrations/20260916_init_krishiflow.sql`:
1. `users` (Role, approval status, account status, PACS society link)
2. `farmers` (Aadhaar masked, land area, bank account, IFSC, GPS coords)
3. `societies` (PACS cooperative code, district, block)
4. `procurement_centres` (Mandi yard, capacity MT/day, queue length, operating hours)
5. `crops` (Crop type, expected quantity kg, harvest date, status)
6. `procurement_requests` (Centre link, transport choice, status)
7. `slots` (Date, 30-min window, capacity, booked count)
8. `bookings` (Token code, QR code, transport_mode, pickup details, status)
9. `queue` (Token sequence, position, called timestamp)
10. `vehicles` (Reg no, vehicle type, capacity kg, GPS lat/lng, status)
11. `trips` (Assigned $\rightarrow$ Arrived $\rightarrow$ Picked Up $\rightarrow$ Mandi $\rightarrow$ Completed)
12. `procurements` (Gross/tare/net weight, moisture %, grade A/B/C, gate pass)
13. `payments` (PFMS status, transaction ID, UTR, credited date)
14. `notifications` (User ID, title, message, type, read status)
15. `offline_farmers` (8-step PACS records, alternate contact SMS, token code)
16. `alerts` (Capacity >90%, slot congestion, vehicle shortages)
17. `vehicle_requests` (Pickup lat/lng, preferred time, assigned vehicle)
18. `audit_logs` (System events, contact submissions)

---

## ⚡ Supabase Edge Functions

Located in `supabase/functions/`:
1. `send-sms` (MSG91 API integration)
2. `check-pfms-status` (PFMS DBT settlement verification)
3. `transcribe-audio` (OpenAI Whisper voice command recognition)
4. `generate-ai-insights` (OpenAI GPT-4 strategic mandi analytics)
5. `assign-vehicle` (Haversine nearest vehicle dispatch algorithm)
6. `calculate-eta` (OSRM driving distance and duration)

---

## 📦 Project Deliverable Files

- **Complete Project Folder**: `c:\Users\RUDRA\OneDrive\Desktop\my project-fpp\`
- **Project Zip Archive**: `c:\Users\RUDRA\OneDrive\Desktop\my project-fpp\krishiflow-ai-sih2026.zip`
