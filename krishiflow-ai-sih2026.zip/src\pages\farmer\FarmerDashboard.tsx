// Farmer Dashboard Home with Live Real-Time Subscriptions
// KRISHIFLOW-AI - Smart India Hackathon 2026 (Problem ID: SIH26032)

import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { 
  Sprout, Calendar, Hourglass, Truck, ArrowRight, ShieldCheck, 
  MapPin, CheckCircle2, Clock, Phone, AlertTriangle, ExternalLink 
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { db, Crop, Booking, QueueItem, Trip, Vehicle } from '../../lib/db';

export const FarmerDashboard: React.FC = () => {
  const { user } = useAuth();

  const [crops, setCrops] = useState<Crop[]>([]);
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [queueItem, setQueueItem] = useState<QueueItem | null>(null);
  const [activeTrip, setActiveTrip] = useState<Trip | null>(null);
  const [assignedVehicle, setAssignedVehicle] = useState<Vehicle | null>(null);

  useEffect(() => {
    const refreshData = () => {
      const allCrops = db.getCollection<Crop>('crops');
      setCrops(allCrops);

      const allBookings = db.getCollection<Booking>('bookings');
      setBookings(allBookings);

      const allQueue = db.getCollection<QueueItem>('queue');
      const myQ = allQueue.find((q) => q.token_code === 'KFA-1024' || q.status === 'waiting') || allQueue[0];
      setQueueItem(myQ || null);

      const allTrips = db.getCollection<Trip>('trips');
      const myTrip = allTrips.find((t) => t.status !== 'completed') || allTrips[0];
      setActiveTrip(myTrip || null);

      if (myTrip) {
        const allVehicles = db.getCollection<Vehicle>('vehicles');
        setAssignedVehicle(allVehicles.find((v) => v.id === myTrip.vehicle_id) || null);
      }
    };

    refreshData();

    // Subscribe to real-time events
    const unsubCrops = db.subscribe('table:crops', refreshData);
    const unsubBookings = db.subscribe('table:bookings', refreshData);
    const unsubQueue = db.subscribe('table:queue', refreshData);
    const unsubTrips = db.subscribe('table:trips', refreshData);

    return () => {
      unsubCrops();
      unsubBookings();
      unsubQueue();
      unsubTrips();
    };
  }, []);

  const nextBooking = bookings[0];
  const activeCrop = crops.find((c) => c.status === 'slot_booked' || c.status === 'vehicle_requested') || crops[0];

  return (
    <div className="space-y-6">
      {/* Welcome Card */}
      <div className="bg-gradient-to-r from-emerald-800 via-green-800 to-teal-800 rounded-3xl p-6 sm:p-8 text-white shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-80 h-80 bg-emerald-600/20 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 space-y-3">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-900/80 border border-emerald-400/30 text-emerald-300 text-xs font-bold uppercase tracking-wider">
            <span>Verified Aadhaar Beneficiary</span>
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
            <span>Sambalpur Mandi Cluster</span>
          </div>

          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
            Welcome Farmer 👋 {user?.name || 'Ramesh Chandra Pradhan'}
          </h1>
          <p className="text-xs sm:text-sm text-emerald-100/90 max-w-2xl leading-relaxed">
            Your centralized procurement portal for automated 30-minute slot scheduling, free government transport vehicle dispatch, live GPS telemetry, and instant PFMS DBT bank settlement.
          </p>

          {/* Action Quick Buttons */}
          <div className="pt-3 flex flex-wrap items-center gap-3">
            <Link
              to="/farmer/procurement"
              className="px-5 py-2.5 rounded-xl bg-emerald-400 hover:bg-emerald-300 text-slate-950 font-extrabold text-xs shadow-md shadow-emerald-400/20 transition-all"
            >
              🌾 Book Mandi Slot
            </Link>
            <Link
              to="/farmer/procurement?mode=vehicle"
              className="px-5 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 border border-white/20 text-white font-bold text-xs backdrop-blur transition-all"
            >
              🚚 Request Vehicle Pickup
            </Link>
            <Link
              to="/farmer/vehicle-tracking"
              className="px-5 py-2.5 rounded-xl bg-teal-950/80 hover:bg-teal-900 border border-teal-500/50 text-teal-300 font-bold text-xs backdrop-blur transition-all"
            >
              📍 Track Vehicle Live
            </Link>
          </div>
        </div>
      </div>

      {/* Stats Cards (3 Columns Real-Time) */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
        {/* Card 1: My Crops */}
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex items-center justify-between">
          <div>
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block">
              Registered Crops
            </span>
            <span className="text-3xl font-extrabold text-slate-900 mt-1 block">
              {crops.length} Batches
            </span>
            <span className="text-[11px] text-emerald-600 font-semibold block mt-0.5">
              Total {(crops.reduce((acc, c) => acc + c.expected_quantity_kg, 0) / 100).toFixed(1)} Quintals
            </span>
          </div>
          <div className="w-12 h-12 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
            <Sprout className="w-6 h-6" />
          </div>
        </div>

        {/* Card 2: Next Slot */}
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex items-center justify-between">
          <div>
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block">
              Next Mandi Slot
            </span>
            <span className="text-xl font-extrabold text-slate-900 mt-1 block">
              {nextBooking ? nextBooking.date : 'No active slot'}
            </span>
            <span className="text-[11px] text-blue-600 font-semibold block mt-0.5">
              {nextBooking ? nextBooking.time_slot : 'Book a slot below'}
            </span>
          </div>
          <div className="w-12 h-12 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center">
            <Calendar className="w-6 h-6" />
          </div>
        </div>

        {/* Card 3: Queue Position (Supabase Realtime) */}
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex items-center justify-between">
          <div>
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block">
              Current Queue Position
            </span>
            <div className="flex items-baseline gap-2 mt-1">
              <span className="text-3xl font-extrabold text-emerald-600">
                #{queueItem ? queueItem.position : 3}
              </span>
              <span className="text-xs text-slate-500 font-medium">in line</span>
            </div>
            <span className="text-[11px] text-amber-600 font-semibold block mt-0.5">
              Est. Wait: ~{(queueItem ? queueItem.position : 3) * 15} Mins
            </span>
          </div>
          <div className="w-12 h-12 rounded-2xl bg-amber-50 text-amber-600 flex items-center justify-center">
            <Hourglass className="w-6 h-6" />
          </div>
        </div>
      </div>

      {/* Active Procurement Card (If Active) */}
      {nextBooking && (
        <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-md">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-100 gap-2">
            <div>
              <span className="text-[10px] font-extrabold uppercase tracking-wider text-emerald-700 bg-emerald-100 px-2.5 py-0.5 rounded-full">
                Active Mandi Booking
              </span>
              <h3 className="font-extrabold text-lg text-slate-900 mt-1">
                Token #{nextBooking.token_number} ({nextBooking.token_code})
              </h3>
            </div>
            <span className="text-xs font-bold text-blue-700 bg-blue-50 px-3 py-1 rounded-xl self-start sm:self-auto">
              Mode: {nextBooking.transport_mode === 'vehicle' ? 'Free Pickup Vehicle' : 'Self Transport'}
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-4 gap-4 py-4 text-xs">
            <div>
              <span className="text-slate-400 block">Crop Type & Est. Weight:</span>
              <span className="font-bold text-slate-800 text-sm">
                {activeCrop?.crop_type || 'Paddy (Common)'} ({activeCrop?.expected_quantity_kg || 2400} kg)
              </span>
            </div>
            <div>
              <span className="text-slate-400 block">Scheduled Date & Time:</span>
              <span className="font-bold text-slate-800 text-sm">
                {nextBooking.date} • {nextBooking.time_slot}
              </span>
            </div>
            <div>
              <span className="text-slate-400 block">Target Mandi:</span>
              <span className="font-bold text-slate-800 text-sm">
                Sambalpur Regulated Mandi Yard
              </span>
            </div>
            <div>
              <span className="text-slate-400 block">Logistics Status:</span>
              <span className="font-bold text-emerald-600 text-sm">
                {activeTrip ? activeTrip.status.replace('_', ' ').toUpperCase() : 'CONFIRMED'}
              </span>
            </div>
          </div>

          <div className="pt-3 border-t border-slate-100 flex flex-wrap items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-2 text-slate-500">
              <Clock className="w-4 h-4 text-emerald-600" />
              <span>Report at Mandi Gate 15 minutes before slot with digital QR Token.</span>
            </div>

            <div className="flex gap-2">
              <Link
                to="/farmer/transport"
                className="px-4 py-2 border border-slate-300 rounded-xl font-semibold text-slate-700 hover:bg-slate-50 transition-colors"
              >
                Transport Details
              </Link>
              {nextBooking.transport_mode === 'vehicle' && (
                <Link
                  to="/farmer/vehicle-tracking"
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl shadow-sm transition-colors flex items-center gap-1.5"
                >
                  <MapPin className="w-3.5 h-3.5" />
                  Track Driver on GPS
                </Link>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
