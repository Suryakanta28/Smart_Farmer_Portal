// Main Sticky Navbar with FPP Leaf Logo, Language Selector & Auth
// KRISHIFLOW-AI - Smart India Hackathon 2026

import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { Leaf, Globe, LogIn, UserPlus, LayoutDashboard, LogOut, Menu, X, Truck } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useLanguage, Language } from '../../context/LanguageContext';

export const Navbar: React.FC = () => {
  const { t } = useTranslation();
  const { user, isAuthenticated, logout } = useAuth();
  const { currentLanguage, changeLanguage } = useLanguage();
  const navigate = useNavigate();

  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const getDashboardPath = () => {
    switch (user?.role) {
      case 'farmer':
        return '/farmer/dashboard';
      case 'society_officer':
        return '/society/dashboard';
      case 'procurement_officer':
        return '/officer/dashboard';
      case 'driver':
        return '/driver/dashboard';
      case 'manager':
        return '/manager/dashboard';
      default:
        return '/farmer/dashboard';
    }
  };

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur border-b border-slate-200 shadow-sm transition-all">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Brand Logo: FPP with Leaf Icon */}
          <Link to="/" className="flex items-center gap-2.5 group">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-600 to-green-500 flex items-center justify-center text-white shadow-md shadow-emerald-500/20 group-hover:scale-105 transition-transform">
              <Leaf className="w-5 h-5 text-emerald-100" />
            </div>
            <div className="flex flex-col">
              <span className="font-extrabold text-xl tracking-tight text-slate-900 flex items-center gap-1.5">
                FPP
                <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 tracking-normal">
                  KRISHIFLOW-AI
                </span>
              </span>
              <span className="text-[10px] text-slate-500 font-medium tracking-wide">
                SIH 2026 • SIH26032
              </span>
            </div>
          </Link>

          {/* Desktop Navigation Links */}
          <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-600">
            <Link to="/" className="hover:text-emerald-600 transition-colors">
              {t('nav.home', 'Home')}
            </Link>
            <a href="#how-it-works" className="hover:text-emerald-600 transition-colors">
              {t('nav.howItWorks', 'How It Works')}
            </a>
            <a href="#centres" className="hover:text-emerald-600 transition-colors">
              {t('nav.centres', 'Procurement Centres')}
            </a>
            <a href="#services" className="hover:text-emerald-600 transition-colors">
              {t('nav.services', 'Services')}
            </a>
            <a href="#about" className="hover:text-emerald-600 transition-colors">
              {t('nav.about', 'About')}
            </a>
            <Link to="/track" className="flex items-center gap-1 text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-md hover:bg-emerald-100 transition-colors font-medium">
              <Truck className="w-4 h-4 text-emerald-600" />
              <span>{t('nav.liveTrack', 'Live Track')}</span>
            </Link>
          </nav>

          {/* Actions: Language Selector, Auth */}
          <div className="hidden md:flex items-center gap-3">
            {/* Language Selector */}
            <div className="relative flex items-center bg-slate-100 hover:bg-slate-200/80 rounded-lg px-2.5 py-1.5 transition-colors">
              <Globe className="w-4 h-4 text-slate-500 mr-1.5" />
              <select
                value={currentLanguage}
                onChange={(e) => changeLanguage(e.target.value as Language)}
                className="bg-transparent text-xs font-semibold text-slate-700 focus:outline-none cursor-pointer"
                aria-label="Language"
              >
                <option value="en">English</option>
                <option value="hi">हिंदी (Hindi)</option>
                <option value="or">ଓଡ଼ିଆ (Odia)</option>
              </select>
            </div>

            {/* Auth Buttons */}
            {isAuthenticated && user ? (
              <div className="flex items-center gap-2">
                <Link
                  to={getDashboardPath()}
                  className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold shadow-sm shadow-emerald-600/20 transition-all"
                >
                  <LayoutDashboard className="w-4 h-4" />
                  <span>Dashboard</span>
                  <span className="capitalize bg-emerald-700 text-white text-[10px] px-1.5 py-0.5 rounded">
                    {user.role.replace('_', ' ')}
                  </span>
                </Link>
                <button
                  onClick={handleLogout}
                  className="p-2 text-slate-500 hover:text-rose-600 rounded-lg hover:bg-rose-50 transition-colors"
                  title="Logout"
                >
                  <LogOut className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <Link
                  to="/login"
                  className="flex items-center gap-1 px-3 py-1.5 rounded-lg text-slate-700 hover:text-emerald-700 hover:bg-emerald-50 text-xs font-semibold transition-colors"
                >
                  <LogIn className="w-4 h-4" />
                  <span>{t('nav.login', 'Login')}</span>
                </Link>
                <Link
                  to="/register"
                  className="flex items-center gap-1 px-3.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold shadow-sm shadow-emerald-600/20 transition-all"
                >
                  <UserPlus className="w-4 h-4" />
                  <span>{t('nav.register', 'Registration')}</span>
                </Link>
              </div>
            )}
          </div>

          {/* Mobile menu hamburger button */}
          <div className="flex md:hidden items-center gap-2">
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-lg text-slate-700 hover:bg-slate-100"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu Dropdown */}
      {mobileMenuOpen && (
        <div className="md:hidden border-t border-slate-200 bg-white px-4 pt-3 pb-5 space-y-3">
          <nav className="flex flex-col gap-2.5 text-sm font-medium text-slate-700">
            <Link to="/" onClick={() => setMobileMenuOpen(false)}>
              {t('nav.home', 'Home')}
            </Link>
            <a href="#how-it-works" onClick={() => setMobileMenuOpen(false)}>
              {t('nav.howItWorks', 'How It Works')}
            </a>
            <a href="#centres" onClick={() => setMobileMenuOpen(false)}>
              {t('nav.centres', 'Procurement Centres')}
            </a>
            <a href="#services" onClick={() => setMobileMenuOpen(false)}>
              {t('nav.services', 'Services')}
            </a>
            <Link to="/track" onClick={() => setMobileMenuOpen(false)} className="text-emerald-600 font-semibold flex items-center gap-1.5">
              <Truck className="w-4 h-4" />
              <span>{t('nav.liveVehicleTracking', 'Live Vehicle Tracking')}</span>
            </Link>
          </nav>

          <div className="pt-2 border-t border-slate-100 flex items-center justify-between">
            <span className="text-xs text-slate-500 font-medium">{t('nav.language', 'Language')}:</span>
            <div className="flex gap-2">
              <button
                onClick={() => changeLanguage('en')}
                className={`text-xs px-2 py-1 rounded ${currentLanguage === 'en' ? 'bg-emerald-600 text-white' : 'bg-slate-100'}`}
              >
                EN
              </button>
              <button
                onClick={() => changeLanguage('hi')}
                className={`text-xs px-2 py-1 rounded ${currentLanguage === 'hi' ? 'bg-emerald-600 text-white' : 'bg-slate-100'}`}
              >
                हिंदी
              </button>
              <button
                onClick={() => changeLanguage('or')}
                className={`text-xs px-2 py-1 rounded ${currentLanguage === 'or' ? 'bg-emerald-600 text-white' : 'bg-slate-100'}`}
              >
                ଓଡ଼ିଆ
              </button>
            </div>
          </div>

          <div className="pt-2 flex flex-col gap-2">
            {isAuthenticated && user ? (
              <>
                <Link
                  to={getDashboardPath()}
                  onClick={() => setMobileMenuOpen(false)}
                  className="w-full text-center py-2 bg-emerald-600 text-white rounded-lg text-xs font-semibold"
                >
                  {t('nav.goToDashboard', 'Go to Dashboard')} ({user.role.replace('_', ' ')})
                </Link>
                <button
                  onClick={() => {
                    handleLogout();
                    setMobileMenuOpen(false);
                  }}
                  className="w-full text-center py-2 bg-rose-50 text-rose-700 rounded-lg text-xs font-semibold"
                >
                  {t('nav.logout', 'Logout')}
                </button>
              </>
            ) : (
              <>
                <Link
                  to="/login"
                  onClick={() => setMobileMenuOpen(false)}
                  className="w-full text-center py-2 bg-slate-100 text-slate-800 rounded-lg text-xs font-semibold"
                >
                  {t('nav.login', 'Login')}
                </Link>
                <Link
                  to="/register"
                  onClick={() => setMobileMenuOpen(false)}
                  className="w-full text-center py-2 bg-emerald-600 text-white rounded-lg text-xs font-semibold"
                >
                  {t('nav.registerNow', 'Register Now')}
                </Link>
              </>
            )}
          </div>
        </div>
      )}
    </header>
  );
};
