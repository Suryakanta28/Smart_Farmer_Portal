// Live Queue Status Page for Farmer with Real-Time Token Calling Subscription
// KRISHIFLOW-AI - Smart India Hackathon 2026 (Problem ID: SIH26032)

import React, { useState, useEffect } from 'react';
import { Hourglass, Clock, Bell, CheckCircle, ShieldAlert, ArrowRight } from 'lucide-react';
import { db, QueueItem } from '../../lib/db';

export const QueueStatusPage: React.FC = () => {
  const [queueItems, setQueueItems] = useState<QueueItem[]>([]);
  const [myQueueItem, setMyQueueItem] = useState<QueueItem | null>(null);

  const avgMinutesPerFarmer = 15;

  useEffect(() => {
    const refreshQueue = () => {
      const all = db.getCollection<QueueItem>('queue');
      setQueueItems(all);

      // Find farmer's current item
      const myItem = all.find((q) => q.token_code === 'KFA-1024' || q.status === 'waiting') || all[0];
      setMyQueueItem(myItem || null);
    };

    refreshQueue();

    // Subscribe to realtime queue events
    const unsub = db.subscribe('table:queue', (data: QueueItem[]) => {
      setQueueItems(data);
      const myItem = data.find((q) => q.token_code === 'KFA-1024' || q.status === 'waiting') || data[0];
      setMyQueueItem(myItem || null);
    });

    return () => unsub();
  }, []);

  const currentPos = myQueueItem ? myQueueItem.position : 3;
  const estimatedWaitMins = currentPos * avgMinutesPerFarmer;
  const isCalled = myQueueItem?.status === 'called';

  const calledHistory = queueItems.filter((q) => q.status === 'called' || q.status === 'completed');

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      {/* Header */}
      <div>
        <span className="text-[10px] font-extrabold uppercase tracking-wider text-emerald-700 bg-emerald-100 px-2.5 py-0.5 rounded-full">
          Live Mandi Telemetry
        </span>
        <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 mt-1">
          Queue & Token Status
        </h2>
        <p className="text-xs text-slate-500">
          Real-time weighbridge sequence synchronized with Sambalpur Mandi gate pass system
        </p>
      </div>

      {/* Alert if Token is CALLED */}
      {isCalled && (
        <div className="p-4 rounded-2xl bg-rose-50 border border-rose-200 text-rose-900 flex items-center justify-between animate-pulse">
          <div className="flex items-center gap-3">
            <Bell className="w-6 h-6 text-rose-600 animate-bounce" />
            <div>
              <h4 className="font-extrabold text-sm">🔔 YOUR TOKEN HAS BEEN CALLED!</h4>
              <p className="text-xs text-rose-700 mt-0.5">
                Proceed to Computerized Weighbridge Bay 1 immediately with your QR Token.
              </p>
            </div>
          </div>
          <span className="px-3 py-1 bg-rose-600 text-white font-bold text-xs rounded-xl">
            Active Call
          </span>
        </div>
      )}

      {/* Large Counter Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {/* Queue Position */}
        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xl text-center space-y-3">
          <span className="text-xs font-bold text-slate-400 uppercase tracking-widest block">
            Your Position in Line
          </span>
          <div className="text-7xl sm:text-8xl font-black text-emerald-600 tracking-tighter">
            #{currentPos}
          </div>
          <p className="text-xs text-slate-500 font-medium">
            Token Code: <b className="text-slate-800">{myQueueItem?.token_code || 'KFA-1024'}</b>
          </p>
          <div className="inline-block px-3 py-1 bg-emerald-50 text-emerald-800 text-xs font-semibold rounded-full border border-emerald-200">
            {currentPos === 1 ? 'You are next in queue!' : `${currentPos - 1} farmers ahead of you`}
          </div>
        </div>

        {/* Estimated Wait Time */}
        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xl text-center space-y-3">
          <span className="text-xs font-bold text-slate-400 uppercase tracking-widest block">
            Estimated Processing Wait
          </span>
          <div className="text-6xl sm:text-7xl font-black text-amber-500 tracking-tighter">
            ~{estimatedWaitMins}
            <span className="text-2xl text-slate-400 font-bold ml-1">mins</span>
          </div>
          <p className="text-xs text-slate-500 font-medium">
            Based on {avgMinutesPerFarmer} mins average weighment and moisture testing
          </p>
          <div className="inline-block px-3 py-1 bg-amber-50 text-amber-800 text-xs font-semibold rounded-full border border-amber-200">
            Auto-recalculated in real-time
          </div>
        </div>
      </div>

      {/* Token Calling History (Last 1 Hour) */}
      <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-md space-y-4">
        <h3 className="font-extrabold text-base text-slate-900 flex items-center gap-2">
          <Clock className="w-4 h-4 text-emerald-600" />
          Recent Mandi Token Call History
        </h3>

        <div className="divide-y divide-slate-100 text-xs">
          {calledHistory.length === 0 ? (
            <p className="py-4 text-center text-slate-400">No token calls in the last hour yet.</p>
          ) : (
            calledHistory.map((item) => (
              <div key={item.id} className="py-3 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center font-bold">
                    #{item.token_number}
                  </div>
                  <div>
                    <h4 className="font-bold text-slate-900">{item.token_code}</h4>
                    <p className="text-[11px] text-slate-500">{item.farmer_name}</p>
                  </div>
                </div>

                <div className="text-right">
                  <span className="font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded text-[10px]">
                    {item.status.toUpperCase()}
                  </span>
                  <span className="text-[10px] text-slate-400 block mt-0.5">
                    {item.called_at ? new Date(item.called_at).toLocaleTimeString() : 'Recently'}
                  </span>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
