// Authentication Context with 5 Role-Based Dashboards
// KRISHIFLOW-AI - Smart India Hackathon 2026

import React, { createContext, useContext, useState, useEffect } from 'react';
import { User, UserRole, db } from '../lib/db';
import { supabase, isLiveSupabaseConfigured } from '../lib/supabase';

interface AuthContextType {
  user: User | null;
  role: UserRole | null;
  isAuthenticated: boolean;
  login: (email: string, password?: string, selectedRole?: UserRole) => Promise<{ success: boolean; error?: string }>;
  logout: () => void;
  switchRole: (newRole: UserRole) => void;
  registerUser: (userData: Partial<User>) => Promise<{ success: boolean; user?: User }>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(() => {
    // Only restore user session if user explicitly logged in during an active session
    const isLoggedIn = localStorage.getItem('kf_is_logged_in');
    if (isLoggedIn === 'true') {
      const saved = localStorage.getItem('kf_current_user');
      if (saved) {
        try {
          return JSON.parse(saved);
        } catch {
          return null;
        }
      }
    } else {
      // Clear any legacy auto-login data so site visits start in a logged-out state
      localStorage.removeItem('kf_current_user');
      localStorage.removeItem('kf_is_logged_in');
    }
    return null; // Public visitors start logged out
  });

  const role = user?.role || null;
  const isAuthenticated = !!user;

  useEffect(() => {
    if (user) {
      localStorage.setItem('kf_current_user', JSON.stringify(user));
      localStorage.setItem('kf_is_logged_in', 'true');
    } else {
      localStorage.removeItem('kf_current_user');
      localStorage.removeItem('kf_is_logged_in');
    }
  }, [user]);

  const login = async (email: string, _password?: string, selectedRole?: UserRole): Promise<{ success: boolean; error?: string }> => {
    // If Supabase live is configured, try Supabase Auth
    if (isLiveSupabaseConfigured()) {
      try {
        const { error } = await supabase.auth.signInWithPassword({
          email,
          password: _password || 'password123',
        });
        if (error) {
          console.warn('Supabase Auth remote failed, falling back to local user store:', error.message);
        }
      } catch (e) {
        console.warn('Supabase Auth error:', e);
      }
    }

    const users = db.getCollection<User>('users');
    let matched = users.find((u) => u.email.toLowerCase() === email.toLowerCase());

    if (!matched && selectedRole) {
      matched = users.find((u) => u.role === selectedRole);
    }

    if (matched) {
      setUser(matched);
      return { success: true };
    }

    // Dynamic user creation if not found
    const created: User = {
      id: `usr-${Date.now()}`,
      role: selectedRole || 'farmer',
      name: email.split('@')[0],
      email: email,
      phone: '+919876543299',
      approval_status: 'approved',
      account_status: 'active',
      created_at: new Date().toISOString(),
    };
    users.push(created);
    db.setCollection('users', users);
    setUser(created);
    return { success: true };
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('kf_current_user');
    localStorage.removeItem('kf_is_logged_in');
    if (isLiveSupabaseConfigured()) {
      supabase.auth.signOut().catch(() => {});
    }
  };

  const switchRole = (newRole: UserRole) => {
    const users = db.getCollection<User>('users');
    const matched = users.find((u) => u.role === newRole);
    if (matched) {
      setUser(matched);
    } else {
      const fallbackUser: User = {
        id: `usr-${newRole}`,
        role: newRole,
        name: `Officer / ${newRole.toUpperCase()}`,
        email: `${newRole}@krishiflow.ai`,
        phone: '+919876543200',
        approval_status: 'approved',
        account_status: 'active',
        created_at: new Date().toISOString(),
      };
      setUser(fallbackUser);
    }
  };

  const registerUser = async (userData: Partial<User>): Promise<{ success: boolean; user?: User }> => {
    const users = db.getCollection<User>('users');
    const newUser: User = {
      id: `usr-${Date.now()}`,
      role: userData.role || 'farmer',
      name: userData.name || 'New Registered User',
      email: userData.email || `user${Date.now()}@krishiflow.ai`,
      phone: userData.phone || '+919876500000',
      approval_status: userData.role === 'farmer' ? 'approved' : 'pending',
      account_status: 'active',
      created_at: new Date().toISOString(),
      ...userData,
    };

    users.push(newUser);
    db.setCollection('users', users);
    setUser(newUser);
    return { success: true, user: newUser };
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        role,
        isAuthenticated,
        login,
        logout,
        switchRole,
        registerUser,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
