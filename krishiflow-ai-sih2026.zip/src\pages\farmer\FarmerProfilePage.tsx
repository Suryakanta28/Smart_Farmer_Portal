// Farmer Profile Page
// KRISHIFLOW-AI - Smart India Hackathon 2026 (Problem ID: SIH26032)

import React from 'react';
import { User, ShieldCheck, MapPin, Building2, Phone, CreditCard } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

export const FarmerProfilePage: React.FC = () => {
  const { user } = useAuth();

  return (
    <div className="space-y-6 max-w-3xl mx-auto">
      <div>
        <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900">
          Farmer Official Profile
        </h2>
        <p className="text-xs text-slate-500">
          State Agriculture Database & Aadhaar-linked verification credentials
        </p>
      </div>

      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xl space-y-6 text-xs">
        {/* Profile Card */}
        <div className="flex items-center gap-4 pb-6 border-b border-slate-100">
          <div className="w-16 h-16 rounded-2xl bg-emerald-600 text-white flex items-center justify-center font-bold text-2xl shadow-lg shadow-emerald-600/20">
            {user?.name?.charAt(0) || 'R'}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="font-extrabold text-lg text-slate-900">{user?.name || 'Ramesh Chandra Pradhan'}</h3>
              <span className="text-[10px] font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-full flex items-center gap-1">
                <ShieldCheck className="w-3 h-3" /> KYC Verified
              </span>
            </div>
            <p className="text-xs text-slate-500">Registration ID: KFA-FARMER-2026-9012</p>
          </div>
        </div>

        {/* Details Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="p-3.5 bg-slate-50 rounded-xl space-y-1">
            <span className="text-slate-400 text-[10px] block">Aadhaar (Masked):</span>
            <span className="font-bold text-slate-800 text-sm">XXXX-XXXX-8921</span>
          </div>

          <div className="p-3.5 bg-slate-50 rounded-xl space-y-1">
            <span className="text-slate-400 text-[10px] block">Mobile (Aadhaar Linked):</span>
            <span className="font-bold text-slate-800 text-sm">{user?.phone || '+91 98765 43201'}</span>
          </div>

          <div className="p-3.5 bg-slate-50 rounded-xl space-y-1">
            <span className="text-slate-400 text-[10px] block">Village & District:</span>
            <span className="font-bold text-slate-800 text-sm">Nuapali Basti, Sambalpur (Odisha)</span>
          </div>

          <div className="p-3.5 bg-slate-50 rounded-xl space-y-1">
            <span className="text-slate-400 text-[10px] block">Cultivated Land Area:</span>
            <span className="font-bold text-slate-800 text-sm">2.4 Hectares (6.0 Acres)</span>
          </div>

          <div className="p-3.5 bg-slate-50 rounded-xl space-y-1">
            <span className="text-slate-400 text-[10px] block">Linked Bank (PFMS DBT):</span>
            <span className="font-bold text-slate-800 text-sm">State Bank of India (A/c ending 8912)</span>
          </div>

          <div className="p-3.5 bg-slate-50 rounded-xl space-y-1">
            <span className="text-slate-400 text-[10px] block">Bank IFSC Code:</span>
            <span className="font-mono font-bold text-slate-800 text-sm">SBIN0000178</span>
          </div>
        </div>
      </div>
    </div>
  );
};
