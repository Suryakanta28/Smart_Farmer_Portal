// Multi-Role Login Page with 1-Click Evaluation Credentials
// KRISHIFLOW-AI - Smart India Hackathon 2026 (Problem ID: SIH26032)

import React, { useState } from 'react';
import { useNavigate, Link, useLocation } from 'react-router-dom';
import { Leaf, LogIn, Lock, Mail, ArrowRight, ShieldCheck, UserCheck, AlertCircle } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { UserRole } from '../../lib/db';
import { Navbar } from '../../components/common/Navbar';
import { Footer } from '../../components/common/Footer';

export const Login: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { login } = useAuth();

  const successMessage = (location.state as any)?.message;

  const [role, setRole] = useState<UserRole>('farmer');
  const [email, setEmail] = useState('farmer@krishiflow.ai');
  const [password, setPassword] = useState('farmer123');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const roleCredentials: Record<UserRole, { email: string; pass: string; title: string; desc: string }> = {
    farmer: {
      email: 'farmer@krishiflow.ai',
      pass: 'farmer123',
      title: '🌾 Farmer',
      desc: 'Book slots, request vehicle pickup, track live GPS, check PFMS DBT',
    },
    society_officer: {
      email: 'society@krishiflow.ai',
      pass: 'society123',
      title: '🏘️ Society Officer (PACS)',
      desc: '8-step offline farmer wizard, token slips, pickup tracking',
    },
    procurement_officer: {
      email: 'officer@krishiflow.ai',
      pass: 'officer123',
      title: '🏢 Procurement Officer',
      desc: 'Live queue token calling, weighbridge grading, smart alerts',
    },
    driver: {
      email: 'driver@krishiflow.ai',
      pass: 'driver123',
      title: '🚚 Vehicle Driver',
      desc: 'Live GPS broadcast, trip status stages, OSRM turn-by-turn',
    },
    manager: {
      email: 'manager@krishiflow.ai',
      pass: 'manager123',
      title: '👨💼 State Manager (IAS)',
      desc: 'OpenAI GPT-4 insights, statewide analytics, mandi congestion',
    },
  };

  const handleRoleChange = (newRole: UserRole) => {
    setRole(newRole);
    setEmail(roleCredentials[newRole].email);
    setPassword(roleCredentials[newRole].pass);
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    const res = await login(email, password, role);
    setLoading(false);

    if (res.success) {
      redirectUser(role);
    } else {
      setError(res.error || 'Invalid credentials. Please select role or use 1-click test fill.');
    }
  };

  const redirectUser = (userRole: UserRole) => {
    switch (userRole) {
      case 'farmer':
        navigate('/farmer/dashboard');
        break;
      case 'society_officer':
        navigate('/society/dashboard');
        break;
      case 'procurement_officer':
        navigate('/officer/dashboard');
        break;
      case 'driver':
        navigate('/driver/dashboard');
        break;
      case 'manager':
        navigate('/manager/dashboard');
        break;
      default:
        navigate('/farmer/dashboard');
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50">
      <Navbar />

      <div className="flex-1 flex items-center justify-center p-4 sm:p-6 lg:p-8">
        <div className="w-full max-w-4xl grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          {/* Left Hero Card: Role Fast Fill */}
          <div className="lg:col-span-5 space-y-4">
            <div className="space-y-2">
              <span className="text-[10px] font-extrabold uppercase tracking-widest text-emerald-600 bg-emerald-50 px-2.5 py-1 rounded-full border border-emerald-200 inline-block">
                SIH26032 Portal Access
              </span>
              <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 leading-tight">
                Role-Based Authentication
              </h2>
              <p className="text-xs text-slate-500">
                Click any role card below to instantly populate credentials and evaluate all 5 production dashboards:
              </p>
            </div>

            <div className="space-y-2">
              {(Object.keys(roleCredentials) as UserRole[]).map((r) => {
                const cred = roleCredentials[r];
                const isSelected = role === r;
                return (
                  <button
                    key={r}
                    type="button"
                    onClick={() => handleRoleChange(r)}
                    className={`w-full text-left p-3 rounded-xl border transition-all text-xs flex items-center justify-between ${
                      isSelected
                        ? 'border-emerald-600 bg-emerald-50/80 ring-2 ring-emerald-500/30 shadow-sm'
                        : 'border-slate-200 bg-white hover:bg-slate-50'
                    }`}
                  >
                    <div>
                      <p className="font-bold text-slate-900">{cred.title}</p>
                      <p className="text-[11px] text-slate-500 line-clamp-1">{cred.desc}</p>
                    </div>
                    {isSelected && (
                      <span className="text-emerald-600 font-bold shrink-0 text-xs">
                        Selected ✓
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Right Form Box */}
          <div className="lg:col-span-7 bg-white p-6 sm:p-8 rounded-3xl shadow-xl border border-slate-200">
            {successMessage && (
              <div className="mb-4 p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-xs text-emerald-800 font-semibold flex items-center gap-2">
                <UserCheck className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>{successMessage}</span>
              </div>
            )}

            {error && (
              <div className="mb-4 p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-800 font-semibold flex items-center gap-2">
                <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                <span>{error}</span>
              </div>
            )}

            <form onSubmit={handleLogin} className="space-y-4">
              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1.5">
                  Select User Role
                </label>
                <select
                  value={role}
                  onChange={(e) => handleRoleChange(e.target.value as UserRole)}
                  className="w-full text-xs font-semibold p-3 bg-slate-50 border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none"
                >
                  <option value="farmer">Farmer (Kisan Portal)</option>
                  <option value="society_officer">Society Officer (PACS)</option>
                  <option value="procurement_officer">Procurement Officer (Mandi Incharge)</option>
                  <option value="driver">Vehicle Driver</option>
                  <option value="manager">State Procurement Manager</option>
                </select>
              </div>

              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1.5">
                  Mobile Number or Email
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="Enter email or 10-digit mobile..."
                    className="w-full text-xs pl-10 pr-4 py-3 bg-slate-50 border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1.5">
                  Password
                </label>
                <div className="relative">
                  <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="password"
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full text-xs pl-10 pr-4 py-3 bg-slate-50 border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none"
                  />
                </div>
              </div>

              <div className="flex items-center justify-between text-xs pt-1">
                <label className="flex items-center gap-2 text-slate-600 cursor-pointer">
                  <input type="checkbox" defaultChecked className="rounded text-emerald-600 focus:ring-emerald-500" />
                  <span>Remember Session</span>
                </label>
                <a href="#helpline" className="text-emerald-700 font-semibold hover:underline">
                  Forgot Password?
                </a>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full py-3.5 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white text-xs font-bold rounded-xl shadow-lg shadow-emerald-600/20 transition-all flex items-center justify-center gap-2 hover:scale-[1.01] active:scale-[0.99]"
              >
                <LogIn className="w-4 h-4" />
                <span>{loading ? 'Authenticating...' : `Enter ${roleCredentials[role].title} Dashboard`}</span>
              </button>
            </form>

            <div className="mt-6 pt-5 border-t border-slate-100 text-center text-xs text-slate-500 space-y-2">
              <p>
                Don't have a registered account yet?{' '}
                <Link to="/register" className="text-emerald-600 font-bold hover:underline">
                  Register as Farmer / Officer →
                </Link>
              </p>
              <p className="text-[11px] text-slate-400">
                🔒 Protected by Supabase Auth and State Agriculture Gateway Encryption
              </p>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
};
