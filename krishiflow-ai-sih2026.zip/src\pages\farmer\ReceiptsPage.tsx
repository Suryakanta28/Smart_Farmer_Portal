// Receipts & Official Procurement Gate Pass Slips for Farmer
// KRISHIFLOW-AI - Smart India Hackathon 2026 (Problem ID: SIH26032)

import React, { useState, useEffect } from 'react';
import { FileText, FileDown, CheckCircle2, ShieldCheck } from 'lucide-react';
import { db, Procurement, Payment } from '../../lib/db';
import { generatePaymentReceiptPdf } from '../../lib/pdf';

export const ReceiptsPage: React.FC = () => {
  const [procurements, setProcurements] = useState<Procurement[]>([]);
  const [payments, setPayments] = useState<Payment[]>([]);

  useEffect(() => {
    setProcurements(db.getCollection<Procurement>('procurements'));
    setPayments(db.getCollection<Payment>('payments'));
  }, []);

  const handleDownload = (proc: Procurement) => {
    const pay = payments.find((p) => p.procurement_id === proc.id) || payments[0];
    generatePaymentReceiptPdf({
      receiptId: proc.id,
      farmerName: proc.farmer_name,
      village: 'Sambalpur Rural',
      cropType: proc.crop_type,
      grossWeightKg: proc.gross_weight_kg,
      tareWeightKg: proc.tare_weight_kg,
      netWeightKg: proc.net_weight_kg,
      moisturePercentage: proc.moisture_percentage,
      qualityGrade: proc.quality_grade,
      mspRatePerQuintal: proc.msp_rate_per_quintal,
      totalAmount: proc.total_amount,
      pfmsTxnId: pay?.pfms_transaction_id || 'PFMS-OD-2026-98124',
      bankRef: pay?.bank_ref_number || 'SBIN0029381923',
      date: new Date(proc.created_at).toLocaleDateString('en-IN'),
    });
  };

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      <div>
        <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900">
          Official Receipts & Gate Slips
        </h2>
        <p className="text-xs text-slate-500">
          Digitally signed certificates of weighment, moisture grading, and DBT clearance
        </p>
      </div>

      <div className="space-y-4">
        {procurements.map((p) => (
          <div
            key={p.id}
            className="bg-white rounded-3xl p-6 border border-slate-200 shadow-md flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4"
          >
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-extrabold uppercase tracking-wider text-blue-700 bg-blue-100 px-2 py-0.5 rounded">
                  {p.gate_pass_number}
                </span>
                <span className="text-xs text-slate-400">
                  {new Date(p.created_at).toLocaleDateString('en-IN')}
                </span>
              </div>
              <h3 className="font-extrabold text-base text-slate-900">
                {p.crop_type} • {p.net_weight_kg} kg ({(p.net_weight_kg / 100).toFixed(2)} Quintals)
              </h3>
              <p className="text-xs text-slate-500">
                Grade: <b className="text-emerald-700">{p.quality_grade}</b> • Moisture: <b>{p.moisture_percentage}%</b> • MSP: ₹ {p.msp_rate_per_quintal}/Q
              </p>
            </div>

            <div className="flex items-center gap-4 w-full sm:w-auto justify-between sm:justify-end">
              <div className="text-right">
                <span className="text-[10px] text-slate-400 block">Settled Amount</span>
                <span className="text-lg font-black text-emerald-600">
                  ₹ {p.total_amount.toLocaleString('en-IN')}
                </span>
              </div>

              <button
                onClick={() => handleDownload(p)}
                className="flex items-center gap-1.5 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-md transition-all"
              >
                <FileDown className="w-4 h-4" />
                <span>PDF Receipt</span>
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
