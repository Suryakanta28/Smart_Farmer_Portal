// Officer / Society / Driver Registration Page
// KRISHIFLOW-AI - Smart India Hackathon 2026 (Problem ID: SIH26032)

import React, { useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { ShieldCheck, UploadCloud, KeyRound, CheckCircle, ArrowLeft, Building, Truck, Users } from 'lucide-react';
import { Navbar } from '../../components/common/Navbar';
import { Footer } from '../../components/common/Footer';
import { db, UserRole } from '../../lib/db';
import { sendSms } from '../../lib/sms';

export const RegisterOfficer: React.FC = () => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const initialRole = (searchParams.get('role') as UserRole) || 'society_officer';

  const [role, setRole] = useState<UserRole>(initialRole);
  const [name, setName] = useState('Anil Kumar Patra');
  const [email, setEmail] = useState('anil.officer@krishiflow.ai');
  const [phone, setPhone] = useState('+919876543888');
  const [designation, setDesignation] = useState('Field Officer / Inspector');
  const [regNo, setRegNo] = useState('OD-15-REG-9812');
  const [docUploaded, setDocUploaded] = useState(false);
  const [otp, setOtp] = useState('');
  const [otpSent, setOtpSent] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleSendOtp = async () => {
    setLoading(true);
    await sendSms({
      phone,
      message: `Your KrishiFlow Officer verification OTP is 7890. Submit to request manager approval.`,
      type: 'otp',
    });
    setOtpSent(true);
    setLoading(false);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (otp !== '7890' && otp !== '1234') {
      alert('Please enter OTP 7890 or 1234');
      return;
    }

    // Insert user with approval_status = 'pending'
    const users = db.getCollection('users');
    users.push({
      id: `usr-${Date.now()}`,
      role,
      name,
      phone,
      email,
      approval_status: 'pending',
      account_status: 'active',
      created_at: new Date().toISOString(),
    });
    db.setCollection('users', users);

    navigate('/login', {
      state: {
        message: `Registration submitted successfully for ${name}. Account is pending Manager Approval.`,
      },
    });
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50">
      <Navbar />

      <main className="flex-1 py-10 px-4 sm:px-6 lg:px-8 max-w-2xl mx-auto w-full">
        <div className="text-center mb-8 space-y-2">
          <span className="text-xs font-extrabold uppercase tracking-widest text-blue-600 bg-blue-50 px-3 py-1 rounded-full border border-blue-200">
            Official Personnel Onboarding
          </span>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 capitalize">
            {role.replace('_', ' ')} Registration
          </h1>
          <p className="text-xs text-slate-500">
            Submit credentials and official identification for Manager clearance
          </p>
        </div>

        <div className="bg-white p-6 sm:p-8 rounded-3xl shadow-xl border border-slate-200">
          <form onSubmit={handleSubmit} className="space-y-4 text-xs">
            <div>
              <label className="font-bold text-slate-700 block mb-1">Official Role</label>
              <select
                value={role}
                onChange={(e) => setRole(e.target.value as UserRole)}
                className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl outline-none font-semibold"
              >
                <option value="society_officer">Society Officer (PACS Incharge)</option>
                <option value="procurement_officer">Procurement Officer (Mandi Mandate)</option>
                <option value="driver">Logistics Vehicle Driver</option>
              </select>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="font-bold text-slate-700 block mb-1">Full Official Name *</label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl outline-none"
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Mobile Number (SMS) *</label>
                <input
                  type="tel"
                  required
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl outline-none"
                />
              </div>
            </div>

            <div>
              <label className="font-bold text-slate-700 block mb-1">Official Email Address *</label>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl outline-none"
              />
            </div>

            {role === 'driver' ? (
              <div>
                <label className="font-bold text-slate-700 block mb-1">Vehicle Registration / DL Number *</label>
                <input
                  type="text"
                  required
                  value={regNo}
                  onChange={(e) => setRegNo(e.target.value)}
                  placeholder="e.g. OD-15-AB-1024 or DL-29381920"
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl outline-none font-mono"
                />
              </div>
            ) : (
              <div>
                <label className="font-bold text-slate-700 block mb-1">Designation & Department *</label>
                <input
                  type="text"
                  required
                  value={designation}
                  onChange={(e) => setDesignation(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl outline-none"
                />
              </div>
            )}

            {/* Document Upload Simulation */}
            <div>
              <label className="font-bold text-slate-700 block mb-1">
                Upload Proof of Appointment / Government ID Proof (PDF or Image) *
              </label>
              <div
                onClick={() => setDocUploaded(true)}
                className={`border-2 border-dashed p-4 rounded-xl text-center cursor-pointer transition-colors ${
                  docUploaded
                    ? 'border-emerald-500 bg-emerald-50 text-emerald-800'
                    : 'border-slate-300 hover:border-blue-500 bg-slate-50'
                }`}
              >
                <UploadCloud className="w-6 h-6 mx-auto mb-1 text-slate-400" />
                <span className="font-semibold block">
                  {docUploaded ? '✓ Identity Certificate Uploaded (Encrypted in Supabase Storage)' : 'Click to Upload Official Identification'}
                </span>
                <span className="text-[10px] text-slate-400">PDF, JPG up to 10MB</span>
              </div>
            </div>

            {/* OTP Section */}
            {!otpSent ? (
              <button
                type="button"
                onClick={handleSendOtp}
                disabled={loading}
                className="w-full py-3 bg-slate-900 hover:bg-black text-white font-bold rounded-xl transition-all"
              >
                {loading ? 'Sending OTP...' : 'Send Mobile Verification OTP (MSG91)'}
              </button>
            ) : (
              <div className="space-y-3 pt-2">
                <div className="p-3 bg-emerald-50 rounded-xl border border-emerald-200 flex items-center justify-between">
                  <span>Enter OTP sent to {phone} (Demo: <b>7890</b>)</span>
                  <input
                    type="text"
                    maxLength={4}
                    value={otp}
                    onChange={(e) => setOtp(e.target.value)}
                    placeholder="7890"
                    className="w-24 text-center p-1.5 bg-white border border-slate-300 rounded-lg font-bold"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl shadow-lg transition-all"
                >
                  Submit Official Registration
                </button>
              </div>
            )}
          </form>
        </div>
      </main>

      <Footer />
    </div>
  );
};
