// 4-Step Farmer Registration Flow with OTP Verification
// KRISHIFLOW-AI - Smart India Hackathon 2026 (Problem ID: SIH26032)

import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  User, ShieldCheck, MapPin, Building2, KeyRound, CheckCircle, 
  ArrowRight, ArrowLeft, Phone, Mail, AlertCircle 
} from 'lucide-react';
import { Navbar } from '../../components/common/Navbar';
import { Footer } from '../../components/common/Footer';
import { InteractiveMap } from '../../components/map/InteractiveMap';
import { db, Society, ProcurementCentre, Farmer } from '../../lib/db';
import { sendSms } from '../../lib/sms';

export const RegisterFarmer: React.FC = () => {
  const navigate = useNavigate();
  const [step, setStep] = useState<number>(1);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string>('');

  const societies = db.getCollection<Society>('societies');
  const centres = db.getCollection<ProcurementCentre>('centres');

  // Form Fields
  const [formData, setFormData] = useState({
    name: 'Debendra Sahu',
    aadhaar: 'XXXX-XXXX-9012',
    village: 'Nuapali',
    district: 'Sambalpur',
    block: 'Maneswar',
    state: 'Odisha',
    land_area_hectares: 2.5,
    bank_account: '982100192831',
    ifsc: 'SBIN0000178',
    mobile: '+919876543999',
    email: 'debendra.farmer@krishiflow.ai',
    password: 'farmerpassword123',
    society_id: societies[0]?.id || 'soc-03',
    centre_id: centres[0]?.id || 'cen-03',
  });

  // OTP State
  const [otpSent, setOtpSent] = useState(false);
  const [enteredOtp, setEnteredOtp] = useState('');
  const [expectedOtp] = useState('7890');

  const handleSendOtp = async () => {
    setLoading(true);
    await sendSms({
      phone: formData.mobile,
      message: `Your KrishiFlow-AI Farmer Verification OTP is ${expectedOtp}. Valid for 10 minutes. (SIH 2026)`,
      type: 'otp',
    });
    setOtpSent(true);
    setLoading(false);
  };

  const handleVerifyAndSubmit = () => {
    if (enteredOtp !== expectedOtp && enteredOtp !== '1234') {
      setError('Invalid OTP. Please enter 7890 or 1234.');
      return;
    }

    setLoading(true);

    // 1. Create user
    const users = db.getCollection('users');
    const newUserId = `usr-${Date.now()}`;
    users.push({
      id: newUserId,
      role: 'farmer',
      name: formData.name,
      phone: formData.mobile,
      email: formData.email,
      approval_status: 'approved',
      account_status: 'active',
      society_id: formData.society_id,
      centre_id: formData.centre_id,
      created_at: new Date().toISOString(),
    });
    db.setCollection('users', users);

    // 2. Create farmer record with kyc_status = 'pending'
    const farmers = db.getCollection<Farmer>('farmers');
    farmers.push({
      id: `far-${Date.now()}`,
      user_id: newUserId,
      name: formData.name,
      father_husband_name: 'Late K. Sahu',
      aadhaar_masked: formData.aadhaar,
      village: formData.village,
      district: formData.district,
      block: formData.block,
      state: formData.state,
      land_area_hectares: Number(formData.land_area_hectares),
      ifsc_code: formData.ifsc,
      kyc_status: 'pending',
      latitude: 21.4669,
      longitude: 83.9812,
      created_at: new Date().toISOString(),
    });
    db.setCollection('farmers', farmers);

    setLoading(false);
    navigate('/login', {
      state: {
        message: 'Registration submitted. Wait for officer approval or login with credentials.',
      },
    });
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50">
      <Navbar />

      <main className="flex-1 py-10 px-4 sm:px-6 lg:px-8 max-w-4xl mx-auto w-full">
        {/* Header */}
        <div className="text-center mb-8 space-y-2">
          <span className="text-xs font-extrabold uppercase tracking-widest text-emerald-600 bg-emerald-50 px-3 py-1 rounded-full border border-emerald-200">
            Kisan Enrollment Portal
          </span>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900">
            4-Step Farmer Registration
          </h1>
          <p className="text-xs text-slate-500">
            Step {step} of 4 • Certified Government Agriculture Marketing Database
          </p>
        </div>

        {/* Progress Bar */}
        <div className="grid grid-cols-4 gap-2 mb-8 text-xs font-semibold text-center">
          {['1. Personal & Bank', '2. Select Society', '3. Select Mandi', '4. OTP Verify'].map(
            (label, idx) => {
              const sNum = idx + 1;
              const isCurr = step === sNum;
              const isPast = step > sNum;
              return (
                <div
                  key={idx}
                  className={`p-2.5 rounded-xl border transition-all ${
                    isCurr
                      ? 'border-emerald-600 bg-emerald-600 text-white shadow-md'
                      : isPast
                      ? 'border-emerald-200 bg-emerald-50 text-emerald-800'
                      : 'border-slate-200 bg-white text-slate-400'
                  }`}
                >
                  <span>{label}</span>
                </div>
              );
            }
          )}
        </div>

        {error && (
          <div className="mb-4 p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-800 font-semibold flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {/* Step Card */}
        <div className="bg-white p-6 sm:p-8 rounded-3xl shadow-xl border border-slate-200">
          {/* STEP 1: Personal & Bank Details */}
          {step === 1 && (
            <div className="space-y-4">
              <h3 className="font-extrabold text-base text-slate-900 flex items-center gap-2">
                <User className="w-5 h-5 text-emerald-600" />
                Step 1: Personal, Land & Bank Account Information
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Farmer Full Name *</label>
                  <input
                    type="text"
                    required
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>

                <div>
                  <label className="font-bold text-slate-700 block mb-1">Aadhaar (Masked) *</label>
                  <input
                    type="text"
                    required
                    value={formData.aadhaar}
                    onChange={(e) => setFormData({ ...formData, aadhaar: e.target.value })}
                    placeholder="XXXX-XXXX-1234"
                    className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>

                <div>
                  <label className="font-bold text-slate-700 block mb-1">Village Name *</label>
                  <input
                    type="text"
                    required
                    value={formData.village}
                    onChange={(e) => setFormData({ ...formData, village: e.target.value })}
                    className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>

                <div>
                  <label className="font-bold text-slate-700 block mb-1">District *</label>
                  <input
                    type="text"
                    required
                    value={formData.district}
                    onChange={(e) => setFormData({ ...formData, district: e.target.value })}
                    className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>

                <div>
                  <label className="font-bold text-slate-700 block mb-1">Total Cultivated Land Area (Hectares) *</label>
                  <input
                    type="number"
                    step="0.1"
                    required
                    value={formData.land_area_hectares}
                    onChange={(e) => setFormData({ ...formData, land_area_hectares: Number(e.target.value) })}
                    className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>

                <div>
                  <label className="font-bold text-slate-700 block mb-1">Mobile Number (SMS Notifications) *</label>
                  <input
                    type="tel"
                    required
                    value={formData.mobile}
                    onChange={(e) => setFormData({ ...formData, mobile: e.target.value })}
                    className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>

                <div>
                  <label className="font-bold text-slate-700 block mb-1">Bank Account Number (PFMS DBT) *</label>
                  <input
                    type="text"
                    required
                    value={formData.bank_account}
                    onChange={(e) => setFormData({ ...formData, bank_account: e.target.value })}
                    className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>

                <div>
                  <label className="font-bold text-slate-700 block mb-1">Bank IFSC Code *</label>
                  <input
                    type="text"
                    required
                    value={formData.ifsc}
                    onChange={(e) => setFormData({ ...formData, ifsc: e.target.value })}
                    className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500 uppercase font-mono"
                  />
                </div>
              </div>

              <div className="pt-4 flex justify-end">
                <button
                  type="button"
                  onClick={() => setStep(2)}
                  className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-md flex items-center gap-1.5"
                >
                  <span>Continue to Step 2</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}

          {/* STEP 2: Select Society */}
          {step === 2 && (
            <div className="space-y-4">
              <h3 className="font-extrabold text-base text-slate-900 flex items-center gap-2">
                <Building2 className="w-5 h-5 text-emerald-600" />
                Step 2: Link Primary Agriculture Cooperative Society (PACS)
              </h3>
              <p className="text-xs text-slate-500">
                Choose the cooperative society nearest to your agricultural land.
              </p>

              <div className="space-y-3">
                {societies.map((soc) => (
                  <div
                    key={soc.id}
                    onClick={() => setFormData({ ...formData, society_id: soc.id })}
                    className={`p-4 rounded-2xl border cursor-pointer transition-all flex items-center justify-between ${
                      formData.society_id === soc.id
                        ? 'border-emerald-600 bg-emerald-50/80 ring-2 ring-emerald-500/20 shadow-sm'
                        : 'border-slate-200 hover:bg-slate-50'
                    }`}
                  >
                    <div>
                      <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded">
                        {soc.code}
                      </span>
                      <h4 className="font-bold text-sm text-slate-900 mt-1">{soc.name}</h4>
                      <p className="text-xs text-slate-500">{soc.address}</p>
                    </div>
                    <span className="text-xs font-bold text-emerald-600">
                      {formData.society_id === soc.id ? '✓ Selected' : 'Choose'}
                    </span>
                  </div>
                ))}
              </div>

              <div className="pt-4 flex items-center justify-between">
                <button
                  type="button"
                  onClick={() => setStep(1)}
                  className="px-4 py-2 border border-slate-300 rounded-xl text-xs font-semibold text-slate-700 flex items-center gap-1"
                >
                  <ArrowLeft className="w-3.5 h-3.5" /> Back
                </button>
                <button
                  type="button"
                  onClick={() => setStep(3)}
                  className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-md flex items-center gap-1.5"
                >
                  <span>Continue to Mandi Selection</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}

          {/* STEP 3: Select Procurement Centre (Map + List) */}
          {step === 3 && (
            <div className="space-y-4">
              <h3 className="font-extrabold text-base text-slate-900 flex items-center gap-2">
                <MapPin className="w-5 h-5 text-emerald-600" />
                Step 3: Select Preferred Procurement Mandi Yard
              </h3>
              <p className="text-xs text-slate-500">
                Choose the official Mandi location where your grain will be weighed and graded.
              </p>

              <InteractiveMap
                selectedCentreId={formData.centre_id}
                onSelectCentre={(c) => setFormData({ ...formData, centre_id: c.id })}
              />

              <div className="pt-4 flex items-center justify-between">
                <button
                  type="button"
                  onClick={() => setStep(2)}
                  className="px-4 py-2 border border-slate-300 rounded-xl text-xs font-semibold text-slate-700 flex items-center gap-1"
                >
                  <ArrowLeft className="w-3.5 h-3.5" /> Back
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setStep(4);
                    handleSendOtp();
                  }}
                  className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-md flex items-center gap-1.5"
                >
                  <span>Proceed to OTP Verification</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}

          {/* STEP 4: OTP Verification (MSG91 API) */}
          {step === 4 && (
            <div className="space-y-6 text-center max-w-md mx-auto py-4">
              <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center mx-auto">
                <KeyRound className="w-8 h-8" />
              </div>

              <div>
                <h3 className="font-extrabold text-xl text-slate-900">
                  Aadhaar Mobile OTP Verification
                </h3>
                <p className="text-xs text-slate-500 mt-1">
                  We sent a 4-digit SMS OTP via MSG91 to{' '}
                  <span className="font-bold text-slate-800">{formData.mobile}</span>
                </p>
                <div className="mt-2 inline-block bg-emerald-50 text-emerald-800 text-xs px-3 py-1 rounded-full border border-emerald-200 font-semibold">
                  Demo Code: Use <b>7890</b> or <b>1234</b>
                </div>
              </div>

              <div className="space-y-3">
                <input
                  type="text"
                  maxLength={4}
                  value={enteredOtp}
                  onChange={(e) => setEnteredOtp(e.target.value)}
                  placeholder="• • • •"
                  className="w-48 mx-auto text-center text-2xl tracking-[0.5em] font-bold p-3 bg-slate-50 border border-slate-300 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500"
                />

                <div className="text-xs text-slate-500">
                  Didn't get the code?{' '}
                  <button
                    type="button"
                    onClick={handleSendOtp}
                    className="text-emerald-700 font-bold hover:underline"
                  >
                    Resend SMS
                  </button>
                </div>
              </div>

              <div className="pt-4 flex items-center justify-between">
                <button
                  type="button"
                  onClick={() => setStep(3)}
                  className="px-4 py-2 border border-slate-300 rounded-xl text-xs font-semibold text-slate-700"
                >
                  Back
                </button>

                <button
                  type="button"
                  disabled={loading || enteredOtp.length < 4}
                  onClick={handleVerifyAndSubmit}
                  className="px-6 py-3 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white font-bold text-xs rounded-xl shadow-lg transition-all flex items-center gap-1.5"
                >
                  <CheckCircle className="w-4 h-4" />
                  <span>{loading ? 'Submitting...' : 'Confirm & Complete Registration'}</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </main>

      <Footer />
    </div>
  );
};
