// SMS Service (MSG91 Integration & Notification Dispatcher)
// KRISHIFLOW-AI - Smart India Hackathon 2026

import { supabase, isLiveSupabaseConfigured } from './supabase';

export interface SmsPayload {
  phone: string;
  message: string;
  type?: 'otp' | 'transactional' | 'alert';
}

export interface SmsLog {
  id: string;
  phone: string;
  message: string;
  timestamp: string;
  status: 'delivered' | 'sent';
}

// Local in-memory log of dispatched SMS messages for live debugging & UI viewing
const dispatchedSmsLogs: SmsLog[] = [];

export async function sendSms(payload: SmsPayload): Promise<{ success: boolean; log: SmsLog }> {
  const log: SmsLog = {
    id: `SMS-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
    phone: payload.phone,
    message: payload.message,
    timestamp: new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
    status: 'delivered',
  };

  dispatchedSmsLogs.unshift(log);

  // If live Supabase Edge Function is configured, trigger it
  if (isLiveSupabaseConfigured()) {
    try {
      await supabase.functions.invoke('send-sms', {
        body: payload,
      });
    } catch (err) {
      console.warn('Edge function send-sms background attempt:', err);
    }
  }

  // Also dispatch browser custom event for live toast notification
  if (typeof window !== 'undefined') {
    window.dispatchEvent(
      new CustomEvent('krishiflow:sms_dispatched', {
        detail: log,
      })
    );
  }

  console.log(`%c[MSG91 SMS DISPATCHED] To: ${payload.phone}\n${payload.message}`, 'color: #16a34a; font-weight: bold;');
  return { success: true, log };
}

export function getDispatchedSmsLogs(): SmsLog[] {
  return [...dispatchedSmsLogs];
}
