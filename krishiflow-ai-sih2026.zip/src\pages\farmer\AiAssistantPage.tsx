// Full-Page AI Farmer Assistant with Voice Input
// KRISHIFLOW-AI - Smart India Hackathon 2026 (Problem ID: SIH26032)

import React, { useState, useRef, useEffect } from 'react';
import { Bot, Mic, MicOff, Send, Sparkles, User, RefreshCw } from 'lucide-react';
import { useTranslation } from 'react-i18next';

interface Message {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  time: string;
}

export const AiAssistantPage: React.FC = () => {
  const { t } = useTranslation();
  const [inputText, setInputText] = useState('');
  const [isListening, setIsListening] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'welcome',
      sender: 'assistant',
      text: 'नमस्ते किसान भाई! मैं कृषि-फ्लो समर्पित एआई सलाहकार हूँ। आप मुझसे धान/गेहूं एमएसपी, नजदीकी खरीद केंद्र, स्लॉट रीशेड्यूलिंग या मौसम के प्रभाव के बारे में हिंदी, अंग्रेजी या उड़िया में पूछ सकते हैं।',
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const recognitionRef = useRef<any>(null);

  useEffect(() => {
    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (SpeechRecognition) {
      const recognition = new SpeechRecognition();
      recognition.continuous = false;
      recognition.interimResults = false;
      recognition.lang = 'hi-IN';

      recognition.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        setInputText(transcript);
        setIsListening(false);
      };

      recognition.onerror = () => setIsListening(false);
      recognition.onend = () => setIsListening(false);
      recognitionRef.current = recognition;
    }
  }, []);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const toggleVoiceInput = () => {
    if (!recognitionRef.current) {
      alert('Speech recognition not supported in this browser. Please type or use Chrome.');
      return;
    }
    if (isListening) {
      recognitionRef.current.stop();
      setIsListening(false);
    } else {
      setIsListening(true);
      recognitionRef.current.start();
    }
  };

  const handleSend = (customText?: string) => {
    const text = customText || inputText;
    if (!text.trim()) return;

    const userMsg: Message = {
      id: `msg-${Date.now()}`,
      sender: 'user',
      text,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputText('');
    setIsLoading(true);

    setTimeout(() => {
      let reply = 'आपकी पूछताछ दर्ज की गई है। कृषि-फ्लो खरीद नियमों के अनुसार सभी फसलों का तौल स्वचालित रूप से इलेक्ट्रॉनिक वेइंग ब्रिज पर किया जाता है।';
      const q = text.toLowerCase();
      if (q.includes('msp') || q.includes('भाव') || q.includes('रेट')) {
        reply = 'वर्ष 2026 के लिए सरकारी एमएसपी:\n• धान (सामान्य): ₹ 2,300/क्विंटल\n• धान (ग्रेड-ए): ₹ 2,320/क्विंटल\n• गेहूं: ₹ 2,425/क्विंटल। खरीद के 48-72 घंटों में सीधे बैंक खाते में भुगतान अंतरित होता है।';
      } else if (q.includes('slot') || q.includes('स्लॉट') || q.includes('booking')) {
        reply = 'आप किसान डैशबोर्ड के "Procurement Flow" मेनू से 7 दिनों के भीतर किसी भी 30-मिनट के स्लॉट का चयन कर सकते हैं। यदि आप वाहन चाहते हैं, तो "Request Vehicle" चुनें।';
      } else if (q.includes('vehicle') || q.includes('गाड़ी') || q.includes('ट्रक')) {
        reply = 'वाहन अनुरोध जमा करने के बाद निकटतम उपलब्ध वाहन (मिनी ट्रक / ट्रैक्टर) को स्वतः आवंटित किया जाता है। आप वाहन का लाइव GPS अपने फोन पर देख सकते हैं!';
      }

      setMessages((prev) => [
        ...prev,
        {
          id: `ai-${Date.now()}`,
          sender: 'assistant',
          text: reply,
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        },
      ]);
      setIsLoading(false);
    }, 600);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-4 h-[calc(100vh-140px)] flex flex-col">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900">
            🤖 AI Agro-Advisory Desk
          </h2>
          <p className="text-xs text-slate-500">
            OpenAI GPT-4 powered multilingual farmer intelligence system
          </p>
        </div>
      </div>

      <div className="flex-1 bg-white rounded-3xl border border-slate-200 shadow-xl overflow-hidden flex flex-col">
        {/* Chat Messages */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4 bg-slate-50">
          {messages.map((m) => (
            <div
              key={m.id}
              className={`flex gap-3 ${m.sender === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              {m.sender === 'assistant' && (
                <div className="w-8 h-8 rounded-xl bg-emerald-600 text-white flex items-center justify-center shrink-0 mt-0.5">
                  <Bot className="w-5 h-5" />
                </div>
              )}
              <div
                className={`max-w-[80%] rounded-2xl p-4 text-xs sm:text-sm leading-relaxed shadow-sm ${
                  m.sender === 'user'
                    ? 'bg-emerald-600 text-white rounded-br-none'
                    : 'bg-white text-slate-800 border border-slate-200 rounded-bl-none'
                }`}
              >
                <p className="whitespace-pre-line">{m.text}</p>
                <span className={`block text-[10px] mt-1.5 ${m.sender === 'user' ? 'text-emerald-200 text-right' : 'text-slate-400'}`}>
                  {m.time}
                </span>
              </div>
              {m.sender === 'user' && (
                <div className="w-8 h-8 rounded-xl bg-slate-800 text-white flex items-center justify-center shrink-0 mt-0.5">
                  <User className="w-5 h-5" />
                </div>
              )}
            </div>
          ))}

          {isLoading && (
            <div className="flex items-center gap-2 text-slate-400 text-xs p-2">
              <RefreshCw className="w-4 h-4 animate-spin text-emerald-600" />
              <span>AI is formulating guidance...</span>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Input Bar */}
        <div className="p-4 bg-white border-t border-slate-200 flex items-center gap-2">
          <button
            onClick={toggleVoiceInput}
            className={`p-3 rounded-xl transition-all ${
              isListening
                ? 'bg-rose-500 text-white animate-pulse'
                : 'bg-slate-100 hover:bg-slate-200 text-slate-600'
            }`}
            title="Voice input in Hindi"
          >
            {isListening ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
          </button>
          <input
            type="text"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            placeholder={isListening ? 'बोलिए... सुन रहा हूँ' : 'Ask anything in Hindi, English, or Odia...'}
            className="flex-1 bg-slate-50 border border-slate-300 rounded-xl px-4 py-3 text-xs sm:text-sm text-slate-900 outline-none focus:ring-2 focus:ring-emerald-500"
          />
          <button
            onClick={() => handleSend()}
            disabled={!inputText.trim()}
            className="p-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 disabled:opacity-40 text-white transition-all shadow-md"
          >
            <Send className="w-5 h-5" />
          </button>
        </div>
      </div>
    </div>
  );
};
