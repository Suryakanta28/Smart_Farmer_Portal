// Public Landing Page (No Login Required)
// KRISHIFLOW-AI - Smart India Hackathon 2026 (Problem ID: SIH26032)

import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { 
  Leaf, Users, Scale, Truck, DollarSign, ArrowRight, ShieldCheck, 
  MapPin, Phone, MessageCircle, Mail, Send, ChevronDown, CheckCircle2, 
  Clock, Sparkles, Navigation, Award, BarChart3, HelpCircle, UserPlus 
} from 'lucide-react';
import { Navbar } from '../components/common/Navbar';
import { Footer } from '../components/common/Footer';
import { WeatherWidget } from '../components/common/WeatherWidget';
import { FloatingAiAssistant } from '../components/common/FloatingAiAssistant';
import { InteractiveMap } from '../components/map/InteractiveMap';
import { db } from '../lib/db';
import { sendSms } from '../lib/sms';

export const Home: React.FC = () => {
  const { t } = useTranslation();

  // Real-time animated counters state
  const [metrics, setMetrics] = useState({
    totalFarmersToday: 0,
    totalProcurementToday: 0,
    activeVehiclesCount: 0,
    totalPaymentsToday: 0,
  });

  const [faqOpen, setFaqOpen] = useState<number | null>(0);

  // Contact form state
  const [contactForm, setContactForm] = useState({
    name: '',
    phone: '',
    email: '',
    message: '',
  });
  const [contactSubmitted, setContactSubmitted] = useState(false);

  // Fetch live procurement metrics every 30s as specified
  useEffect(() => {
    const updateMetrics = () => {
      const live = db.getLiveMetrics();
      setMetrics(live);
    };

    updateMetrics();
    const interval = setInterval(updateMetrics, 30000);
    return () => clearInterval(interval);
  }, []);

  const handleContactSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!contactForm.name || !contactForm.phone) return;

    // Save contact message to database audit logs
    const logs = db.getCollection('audit_logs');
    logs.push({
      id: `contact-${Date.now()}`,
      action: 'contact_form_submitted',
      entity: 'support',
      details: contactForm,
      created_at: new Date().toISOString(),
    });
    db.setCollection('audit_logs', logs);

    // Trigger SMS acknowledgement
    sendSms({
      phone: contactForm.phone,
      message: `Dear ${contactForm.name}, your query has been received by KrishiFlow Support. Reference: #KF-${Date.now().toString().slice(-4)}. Helpline: 1800-180-2026.`,
      type: 'transactional',
    });

    setContactSubmitted(true);
    setContactForm({ name: '', phone: '', email: '', message: '' });
  };

  const faqs = [
    {
      q: t('faq.q1', 'How does the automated slot booking work for farmers?'),
      a: t('faq.a1', 'Farmers can select their crop and transport method. If you choose Self Transport, you can directly book any available 30-minute slot at your mandi. If you choose Vehicle Pickup, a nearby vehicle is automatically allocated to your village first, and your slot is scheduled after arrival.'),
    },
    {
      q: t('faq.q2', 'What if a farmer does not have a smartphone or internet access?'),
      a: t('faq.a2', 'KrishiFlow-AI provides an 8-Step Offline Assistance module for Primary Agricultural Cooperative Society (PACS) officers. Officers enter the farmer’s Aadhaar and crop details, assign a transport trolley, and generate a physical printed token slip with QR code while sending SMS updates to an alternate family contact.'),
    },
    {
      q: t('faq.q3', 'How are DBT payments cleared through PFMS?'),
      a: t('faq.a3', 'Immediately after automated digital weighment and computer-graded moisture analysis, a Gate Pass is created. The Direct Benefit Transfer (DBT) payment instruction is sent via the PFMS gateway directly to the farmer’s Aadhaar-linked bank account, crediting funds within 48 to 72 hours.'),
    },
    {
      q: t('faq.q4', 'How can I track the vehicle carrying my crop?'),
      a: t('faq.a4', 'The platform integrates real-time GPS tracking using Leaflet and OSRM routing. Both farmers and mandi officers can view live vehicle markers moving every 10 seconds, check live ETAs, and call the driver directly from the dashboard.'),
    },
    {
      q: t('faq.q5', 'What crops are eligible under MSP procurement?'),
      a: t('faq.a5', 'The system supports all primary kharif and rabi staples including Paddy (Common & Grade A), Wheat (Sharbati & Standard), Maize, Mustard, and Pulses, according to the official state MSP procurement guidelines.'),
    },
  ];

  return (
    <div className="min-h-screen flex flex-col bg-slate-50">
      <Navbar />

      {/* HERO SECTION: Full Viewport Height with Agricultural Background */}
      <section className="relative min-h-[90vh] flex items-center justify-center bg-gradient-to-br from-emerald-950 via-slate-900 to-green-950 text-white overflow-hidden py-16 px-4 sm:px-6 lg:px-8">
        {/* Subtle Background Pattern & Glow */}
        <div className="absolute inset-0 opacity-20 bg-[radial-gradient(#22c55e_1px,transparent_1px)] [background-size:24px_24px] pointer-events-none" />
        <div className="absolute -top-40 -left-40 w-96 h-96 bg-emerald-500/20 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-40 -right-40 w-96 h-96 bg-green-500/20 rounded-full blur-3xl pointer-events-none" />

        <div className="relative max-w-5xl mx-auto text-center z-10 space-y-8">
          {/* SIH 2026 Badge */}
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-emerald-900/80 border border-emerald-500/40 text-emerald-300 text-xs font-bold uppercase tracking-wider backdrop-blur animate-fade-in shadow-lg shadow-emerald-900/30">
            <Sparkles className="w-4 h-4 text-amber-400" />
            <span>{t('hero.badge', 'Smart India Hackathon 2026 • Problem ID: SIH26032')}</span>
          </div>

          {/* Headline & Subheadline */}
          <div className="space-y-4">
            <h1 className="text-4xl sm:text-6xl lg:text-7xl font-extrabold tracking-tight leading-[1.1] text-white">
              {t('hero.titlePart1', 'Smart Farmer')}{' '}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 via-green-300 to-amber-300">
                {t('hero.titlePart2', 'Procurement')}
              </span>{' '}
              {t('hero.titlePart3', 'Platform')}
            </h1>
            <p className="text-base sm:text-xl text-slate-300 max-w-3xl mx-auto font-medium leading-relaxed">
              {t('hero.subheadline', 'Connect Farmers • Societies • Procurement Centres • Vehicles')}
            </p>
          </div>

          {/* CTAs */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-4">
            <Link
              to="/register"
              className="w-full sm:w-auto flex items-center justify-center gap-2 px-8 py-4 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-extrabold text-sm shadow-xl shadow-emerald-500/25 transition-all hover:scale-105 active:scale-95"
            >
              <UserPlus className="w-5 h-5" />
              <span>{t('hero.registerNow', 'Register Now')}</span>
            </Link>

            <Link
              to="/login"
              className="w-full sm:w-auto flex items-center justify-center gap-2 px-8 py-4 rounded-xl bg-white/10 hover:bg-white/20 border border-white/20 text-white font-bold text-sm backdrop-blur transition-all hover:scale-105"
            >
              <span>{t('hero.loginToPortal', 'Login to Portal')}</span>
              <ArrowRight className="w-4 h-4 text-emerald-400" />
            </Link>

            <Link
              to="/track"
              className="w-full sm:w-auto flex items-center justify-center gap-2 px-6 py-4 rounded-xl bg-emerald-950/80 hover:bg-emerald-900 border border-emerald-500/50 text-emerald-300 font-bold text-sm backdrop-blur transition-all"
            >
              <Truck className="w-4 h-4" />
              <span>{t('hero.trackVehicle', 'Live Vehicle GPS')}</span>
            </Link>
          </div>

          {/* 5 Role Direct Badges */}
          <div className="pt-8 border-t border-slate-800/80 flex flex-wrap items-center justify-center gap-2 text-xs text-slate-400">
            <span className="font-semibold text-slate-300">{t('hero.rolesTitle', '5 Integrated Roles:')}</span>
            <span className="px-2.5 py-1 bg-white/5 rounded-md border border-white/10 text-emerald-300">🌾 {t('hero.roleFarmer', 'Farmer')}</span>
            <span className="px-2.5 py-1 bg-white/5 rounded-md border border-white/10 text-blue-300">🏘️ {t('hero.roleSociety', 'Society PACS')}</span>
            <span className="px-2.5 py-1 bg-white/5 rounded-md border border-white/10 text-teal-300">🏢 {t('hero.roleOfficer', 'Procurement Mandi')}</span>
            <span className="px-2.5 py-1 bg-white/5 rounded-md border border-white/10 text-amber-300">🚚 {t('hero.roleDriver', 'Vehicle Driver')}</span>
            <span className="px-2.5 py-1 bg-white/5 rounded-md border border-white/10 text-purple-300">👨💼 {t('hero.roleManager', 'State Manager')}</span>
          </div>
        </div>
      </section>

      {/* FEATURE 2: LIVE PROCUREMENT STATUS (Auto-refresh every 30s) */}
      <section className="py-12 bg-white border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-8">
            <span className="text-xs font-extrabold uppercase tracking-widest text-emerald-600">
              {t('liveStatus.tag', 'Live Mandi Network Stream')}
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 mt-1">
              {t('liveStatus.title', 'Live Procurement Status')}
            </h2>
            <p className="text-xs text-slate-500 mt-1">
              {t('liveStatus.subtitle', 'Auto-refreshed from active weighbridges and PFMS DBT settlement servers')}
            </p>
          </div>

          {/* 4 Metrics Cards with Animated Counters */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {/* Card 1: Total Farmers Today */}
            <div className="bg-gradient-to-br from-emerald-50 to-white p-6 rounded-2xl border border-emerald-100 shadow-sm flex items-center gap-4">
              <div className="w-14 h-14 rounded-2xl bg-emerald-600 text-white flex items-center justify-center shrink-0 shadow-md shadow-emerald-600/20">
                <Users className="w-7 h-7" />
              </div>
              <div>
                <span className="text-xs font-semibold text-slate-500 block">
                  {t('liveStatus.farmersToday', 'Total Farmers Today')}
                </span>
                <span className="text-3xl font-extrabold text-slate-900 tracking-tight">
                  {metrics.totalFarmersToday.toLocaleString('en-IN')}
                </span>
                <span className="text-[10px] text-emerald-600 font-bold block mt-0.5">
                  {t('liveStatus.farmersSub', '↑ +18% from yesterday')}
                </span>
              </div>
            </div>

            {/* Card 2: Total Procurement Today (Quintals) */}
            <div className="bg-gradient-to-br from-blue-50 to-white p-6 rounded-2xl border border-blue-100 shadow-sm flex items-center gap-4">
              <div className="w-14 h-14 rounded-2xl bg-blue-600 text-white flex items-center justify-center shrink-0 shadow-md shadow-blue-600/20">
                <Scale className="w-7 h-7" />
              </div>
              <div>
                <span className="text-xs font-semibold text-slate-500 block">
                  {t('liveStatus.procurementToday', 'Total Procurement (Q)')}
                </span>
                <span className="text-3xl font-extrabold text-slate-900 tracking-tight">
                  {metrics.totalProcurementToday.toLocaleString('en-IN')}
                </span>
                <span className="text-[10px] text-blue-600 font-bold block mt-0.5">
                  {t('liveStatus.procurementSub', 'Verified Digital Weight')}
                </span>
              </div>
            </div>

            {/* Card 3: Active Vehicles On Trip */}
            <div className="bg-gradient-to-br from-amber-50 to-white p-6 rounded-2xl border border-amber-100 shadow-sm flex items-center gap-4">
              <div className="w-14 h-14 rounded-2xl bg-amber-600 text-white flex items-center justify-center shrink-0 shadow-md shadow-amber-600/20">
                <Truck className="w-7 h-7" />
              </div>
              <div>
                <span className="text-xs font-semibold text-slate-500 block">
                  {t('liveStatus.activeVehicles', 'Active Vehicles')}
                </span>
                <span className="text-3xl font-extrabold text-slate-900 tracking-tight">
                  {metrics.activeVehiclesCount}
                </span>
                <span className="text-[10px] text-amber-600 font-bold block mt-0.5">
                  {t('liveStatus.activeVehiclesSub', 'Live GPS Broadcasting')}
                </span>
              </div>
            </div>

            {/* Card 4: Payments Today (DBT) */}
            <div className="bg-gradient-to-br from-purple-50 to-white p-6 rounded-2xl border border-purple-100 shadow-sm flex items-center gap-4">
              <div className="w-14 h-14 rounded-2xl bg-purple-600 text-white flex items-center justify-center shrink-0 shadow-md shadow-purple-600/20">
                <DollarSign className="w-7 h-7" />
              </div>
              <div>
                <span className="text-xs font-semibold text-slate-500 block">
                  {t('liveStatus.paymentsToday', 'Payments Today (DBT)')}
                </span>
                <span className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
                  ₹ {(metrics.totalPaymentsToday / 100000).toFixed(2)}L
                </span>
                <span className="text-[10px] text-purple-600 font-bold block mt-0.5">
                  {t('liveStatus.paymentsSub', 'PFMS Direct Settlement')}
                </span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FEATURE 1: FIND PROCUREMENT CENTRE (INTERACTIVE MAP & LIST) */}
      <section id="centres" className="py-16 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
        <div className="text-center mb-8">
          <span className="text-xs font-extrabold uppercase tracking-widest text-emerald-600">
            {t('centres.tag', 'Interactive GIS Locator')}
          </span>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 mt-1">
            {t('centres.title', 'Find Procurement Centre')}
          </h2>
          <p className="text-xs text-slate-500 mt-1 max-w-2xl mx-auto">
            {t('centres.subtitle', 'Locate authorized Mandis with live queue tracking, wait times, and direct turn-by-turn OSRM routing')}
          </p>
        </div>

        <InteractiveMap showBookSlotButton={false} />
      </section>

      {/* HOW IT WORKS: CRITICAL TRANSPORT MODE FLOW */}
      <section id="how-it-works" className="py-16 bg-white border-y border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <span className="text-xs font-extrabold uppercase tracking-widest text-emerald-600">
              {t('howItWorks.tag', 'End-to-End Workflow')}
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 mt-1">
              {t('howItWorks.title', 'How KrishiFlow-AI Automates Procurement')}
            </h2>
            <p className="text-xs text-slate-500 mt-1">
              {t('howItWorks.subtitle', 'Dynamic path selection based on farmer transport needs')}
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* Flow A: Self Transport */}
            <div className="p-6 rounded-2xl bg-slate-50 border border-slate-200 space-y-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-emerald-600 text-white flex items-center justify-center font-bold">
                  🚜
                </div>
                <div>
                  <h3 className="font-extrabold text-base text-slate-900">
                    {t('howItWorks.optionATitle', 'Option A: Self Transport')}
                  </h3>
                  <span className="text-xs text-emerald-700 font-semibold">{t('howItWorks.optionASub', 'Direct 7-Day Slot Booking')}</span>
                </div>
              </div>
              <ul className="space-y-2.5 text-xs text-slate-600">
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                  <span>{t('howItWorks.optionABullet1', 'Farmer selects crop and procurement mandi yard.')}</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                  <span>{t('howItWorks.optionABullet2', 'Immediate calendar grid (7 days × 30-min intervals) to pick slot.')}</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                  <span>{t('howItWorks.optionABullet3', 'Generates official token (e.g. #KFA-1024) + QR code + PDF download.')}</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                  <span>{t('howItWorks.optionABullet4', 'Automatic SMS sent via MSG91 with turn directions.')}</span>
                </li>
              </ul>
            </div>

            {/* Flow B: Vehicle Pickup Request */}
            <div className="p-6 rounded-2xl bg-slate-50 border border-slate-200 space-y-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-blue-600 text-white flex items-center justify-center font-bold">
                  🚚
                </div>
                <div>
                  <h3 className="font-extrabold text-base text-slate-900">
                    {t('howItWorks.optionBTitle', 'Option B: Request Vehicle Pickup')}
                  </h3>
                  <span className="text-xs text-blue-700 font-semibold">{t('howItWorks.optionBSub', 'Smart Nearest Fleet Assignment First')}</span>
                </div>
              </div>
              <ul className="space-y-2.5 text-xs text-slate-600">
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
                  <span>{t('howItWorks.optionBBullet1', 'Farmer requests free vehicle pickup with preferred morning hour (7:00-8:00 AM).')}</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
                  <span>{t('howItWorks.optionBBullet2', 'Haversine algorithm matches nearest available vehicle with capacity.')}</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
                  <span>{t('howItWorks.optionBBullet3', 'Slot is locked to ≥ 2 hours after pickup to prevent mandi bottleneck.')}</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
                  <span>{t('howItWorks.optionBBullet4', 'Farmer tracks driver on real-time GPS map with 10-second updates.')}</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* FEATURE 4: AGRICULTURAL WEATHER WIDGET */}
      <section className="py-16 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
        <WeatherWidget />
      </section>

      {/* FEATURE 5: CONTACT & FAQ SECTION */}
      <section id="about" className="py-16 bg-white border-t border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Contact Details & SendGrid Form */}
            <div className="space-y-6">
              <div>
                <span className="text-xs font-extrabold uppercase tracking-widest text-emerald-600">
                  {t('contact.tag', 'Direct Support Network')}
                </span>
                <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 mt-1">
                  {t('contact.title', 'Connect with Procurement Desk')}
                </h2>
                <p className="text-xs text-slate-500 mt-1">
                  {t('contact.subtitle', '24/7 Toll-free assistance, WhatsApp chat, or direct message')}
                </p>
              </div>

              {/* Quick Helpline Buttons */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <a
                  href="tel:18001802026"
                  className="flex items-center gap-3 p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-900 hover:bg-emerald-100 transition-colors"
                >
                  <div className="w-10 h-10 rounded-lg bg-emerald-600 text-white flex items-center justify-center shrink-0">
                    <Phone className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-500 block font-semibold">{t('contact.helplineTitle', 'Toll-Free Helpline')}</span>
                    <span className="text-sm font-extrabold">1800-180-2026</span>
                  </div>
                </a>

                <a
                  href="https://wa.me/919876543201?text=Hello%20KrishiFlow"
                  target="_blank"
                  rel="noreferrer"
                  className="flex items-center gap-3 p-4 rounded-xl bg-green-50 border border-green-200 text-green-900 hover:bg-green-100 transition-colors"
                >
                  <div className="w-10 h-10 rounded-lg bg-green-600 text-white flex items-center justify-center shrink-0">
                    <MessageCircle className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-500 block font-semibold">{t('contact.whatsappTitle', 'WhatsApp Desk')}</span>
                    <span className="text-sm font-extrabold">+91 98765 43201</span>
                  </div>
                </a>
              </div>

              {/* Contact Form */}
              <form onSubmit={handleContactSubmit} className="p-5 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
                <span className="text-xs font-bold text-slate-800 block">
                  {t('contact.formTitle', 'Send a Direct Message to Mandi Control Room:')}
                </span>

                {contactSubmitted && (
                  <div className="p-3 bg-emerald-100 text-emerald-800 text-xs font-semibold rounded-xl flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    {t('contact.formSuccess', 'Thank you! Your message has been routed and SMS confirmation sent.')}
                  </div>
                )}

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                  <input
                    type="text"
                    placeholder={t('contact.namePlaceholder', 'Farmer / Citizen Name *')}
                    required
                    value={contactForm.name}
                    onChange={(e) => setContactForm({ ...contactForm, name: e.target.value })}
                    className="p-2.5 bg-white border border-slate-300 rounded-lg outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                  <input
                    type="tel"
                    placeholder={t('contact.phonePlaceholder', 'Mobile Number (for SMS) *')}
                    required
                    value={contactForm.phone}
                    onChange={(e) => setContactForm({ ...contactForm, phone: e.target.value })}
                    className="p-2.5 bg-white border border-slate-300 rounded-lg outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>

                <input
                  type="email"
                  placeholder={t('contact.emailPlaceholder', 'Email Address (Optional)')}
                  value={contactForm.email}
                  onChange={(e) => setContactForm({ ...contactForm, email: e.target.value })}
                  className="w-full text-xs p-2.5 bg-white border border-slate-300 rounded-lg outline-none focus:ring-2 focus:ring-emerald-500"
                />

                <textarea
                  rows={3}
                  placeholder={t('contact.messagePlaceholder', 'Your procurement query or grievance...')}
                  required
                  value={contactForm.message}
                  onChange={(e) => setContactForm({ ...contactForm, message: e.target.value })}
                  className="w-full text-xs p-2.5 bg-white border border-slate-300 rounded-lg outline-none focus:ring-2 focus:ring-emerald-500"
                />

                <button
                  type="submit"
                  className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl shadow-md transition-all flex items-center justify-center gap-1.5"
                >
                  <Send className="w-3.5 h-3.5" />
                  {t('contact.submitButton', 'Submit Message (SendGrid & SMS)')}
                </button>
              </form>
            </div>

            {/* FAQ Accordion (5 Questions) */}
            <div className="space-y-4">
              <div>
                <span className="text-xs font-extrabold uppercase tracking-widest text-emerald-600">
                  {t('faq.tag', 'Knowledge Base')}
                </span>
                <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 mt-1">
                  {t('faq.title', 'Frequently Asked Questions')}
                </h2>
                <p className="text-xs text-slate-500 mt-1">
                  {t('faq.subtitle', 'Key answers regarding procurement rules, tokens, and PFMS payments')}
                </p>
              </div>

              <div className="space-y-2.5">
                {faqs.map((faq, i) => (
                  <div
                    key={i}
                    className="border border-slate-200 rounded-xl overflow-hidden bg-slate-50 transition-all"
                  >
                    <button
                      onClick={() => setFaqOpen(faqOpen === i ? null : i)}
                      className="w-full p-4 text-left flex items-center justify-between text-xs font-bold text-slate-800 hover:bg-slate-100"
                    >
                      <span>{faq.q}</span>
                      <ChevronDown
                        className={`w-4 h-4 text-slate-400 transition-transform ${
                          faqOpen === i ? 'rotate-180 text-emerald-600' : ''
                        }`}
                      />
                    </button>
                    {faqOpen === i && (
                      <div className="px-4 pb-4 text-xs text-slate-600 leading-relaxed bg-white border-t border-slate-100">
                        {faq.a}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Floating AI Assistant Widget */}
      <FloatingAiAssistant />

      <Footer />
    </div>
  );
};
