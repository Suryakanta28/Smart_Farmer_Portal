// Procurement Flow Wizard: Self Transport vs Request Vehicle
// KRISHIFLOW-AI - Smart India Hackathon 2026 (Problem ID: SIH26032)

import React, { useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { 
  Sprout, MapPin, Truck, Calendar, CheckCircle2, ArrowRight, 
  ArrowLeft, Clock, Phone, AlertCircle, Navigation, FileDown 
} from 'lucide-react';
import { db, ProcurementCentre, Vehicle, Crop } from '../../lib/db';
import { InteractiveMap } from '../../components/map/InteractiveMap';
import { generateTokenPdf } from '../../lib/pdf';
import { sendSms } from '../../lib/sms';

export const ProcurementFlow: React.FC = () => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const initialMode = (searchParams.get('mode') as 'self' | 'vehicle') || 'self';

  // Step state: 1 (Crop), 2 (Centre), 3 (Transport Selection), 4A (Self Slot), 4B (Vehicle Req), 5B (Vehicle Slot), 6 (Success)
  const [currentStep, setCurrentStep] = useState<number>(1);
  const [transportMode, setTransportMode] = useState<'self' | 'vehicle'>(initialMode);

  // Form states
  const [cropType, setCropType] = useState('Paddy (Common)');
  const [cropQuantityKg, setCropQuantityKg] = useState<number>(2400);
  const [harvestDate, setHarvestDate] = useState(new Date().toISOString().split('T')[0]);

  const centres = db.getCollection<ProcurementCentre>('centres');
  const [selectedCentre, setSelectedCentre] = useState<ProcurementCentre>(centres[0]);

  // Self Transport Slot
  const [selectedDate, setSelectedDate] = useState(new Date(Date.now() + 86400000).toISOString().split('T')[0]);
  const [selectedSlot, setSelectedSlot] = useState('10:00 AM - 10:30 AM');

  // Vehicle Request Form
  const [pickupLocation, setPickupLocation] = useState('Nilokheri / Sambalpur Rural');
  const [pickupAddress, setPickupAddress] = useState('House #42, Main Canal Road, Near Primary Health Centre');
  const [preferredPickupTime, setPreferredPickupTime] = useState('07:30 AM');
  const [specialInstructions, setSpecialInstructions] = useState('Crop packed in standard 50kg jute bags');
  const [alternatePhone, setAlternatePhone] = useState('+919876549900');

  // Vehicle matching state
  const [vehiclePending, setVehiclePending] = useState(false);
  const [assignedDriver, setAssignedDriver] = useState<Vehicle | null>(null);

  // Generated token state
  const [generatedToken, setGeneratedToken] = useState<{ token_code: string; token_number: number } | null>(null);

  // Slots generation (7 days x 30 min intervals)
  const daysList = Array.from({ length: 7 }, (_, i) => {
    const d = new Date(Date.now() + (i + 1) * 86400000);
    return d.toISOString().split('T')[0];
  });

  const timeSlotsAll = [
    '09:00 AM - 09:30 AM',
    '09:30 AM - 10:00 AM',
    '10:00 AM - 10:30 AM',
    '10:30 AM - 11:00 AM',
    '11:00 AM - 11:30 AM',
    '11:30 AM - 12:00 PM',
    '02:00 PM - 02:30 PM',
    '02:30 PM - 03:00 PM',
    '03:00 PM - 03:30 PM',
    '03:30 PM - 04:00 PM',
    '04:00 PM - 04:30 PM',
    '04:30 PM - 05:00 PM',
  ];

  // For Vehicle transport: ONLY show slots >= 2 hours after preferred pickup time
  const timeSlotsVehicle = timeSlotsAll.filter((s) => {
    if (preferredPickupTime.startsWith('07')) {
      return !s.startsWith('09:00');
    }
    return true;
  });

  // Step 1 -> Step 2
  const handleStep1Next = () => {
    // Save to crops table, status = 'procurement_requested'
    db.addCrop({
      farmer_id: 'far-01',
      crop_type: cropType,
      expected_quantity_kg: cropQuantityKg,
      harvest_date: harvestDate,
    });
    setCurrentStep(2);
  };

  // Step 2 -> Step 3
  const handleStep2Next = () => {
    setCurrentStep(3);
  };

  // Step 3 Transport selection
  const handleStep3Next = () => {
    if (transportMode === 'self') {
      setCurrentStep(41); // Step 4A
    } else {
      setCurrentStep(42); // Step 4B
    }
  };

  // Step 4A: Confirm Self Transport Slot
  const handleConfirmSelfSlot = () => {
    const booking = db.bookSelfTransportSlot({
      farmer_id: 'far-01',
      centre_id: selectedCentre.id,
      date: selectedDate,
      time_slot: selectedSlot,
      farmerName: 'Ramesh Chandra Pradhan',
      farmerPhone: '+919876543201',
    });

    setGeneratedToken({
      token_code: booking.token_code,
      token_number: booking.token_number,
    });
    setCurrentStep(6);
  };

  // Step 4B: Submit Vehicle Request
  const handleSubmitVehicleRequest = () => {
    setVehiclePending(true);

    const { vehicleRequest, assignedVehicle } = db.submitVehicleRequest({
      farmer_id: 'far-01',
      crop_quantity_kg: cropQuantityKg,
      pickup_location: pickupLocation,
      pickup_latitude: 21.4820,
      pickup_longitude: 83.9620,
      preferred_pickup_time: preferredPickupTime,
      special_instructions: specialInstructions,
      alternate_phone: alternatePhone,
      farmerName: 'Ramesh Chandra Pradhan',
      farmerPhone: '+919876543201',
    });

    // Simulate smart assignment notification
    setTimeout(() => {
      setAssignedDriver(assignedVehicle);
      setVehiclePending(false);
    }, 1200);
  };

  // Step 5B: Confirm Vehicle Slot Booking (After Vehicle Assigned)
  const handleConfirmVehicleSlot = () => {
    const booking = db.confirmVehicleSlotBooking({
      farmer_id: 'far-01',
      centre_id: selectedCentre.id,
      date: selectedDate,
      time_slot: selectedSlot,
      pickup_location: pickupLocation,
      pickup_latitude: 21.4820,
      pickup_longitude: 83.9620,
      preferred_pickup_time: preferredPickupTime,
      farmerName: 'Ramesh Chandra Pradhan',
      farmerPhone: '+919876543201',
      driverName: assignedDriver?.driver_name,
      driverPhone: assignedDriver?.driver_phone,
    });

    setGeneratedToken({
      token_code: booking.token_code,
      token_number: booking.token_number,
    });
    setCurrentStep(6);
  };

  const handleDownloadPdf = () => {
    if (!generatedToken) return;
    generateTokenPdf({
      tokenCode: generatedToken.token_code,
      tokenNumber: generatedToken.token_number,
      farmerName: 'Ramesh Chandra Pradhan',
      farmerPhone: '+919876543201',
      village: pickupLocation,
      district: 'Sambalpur',
      cropType,
      cropQuantityKg,
      centreName: selectedCentre.name,
      centreAddress: selectedCentre.address,
      date: selectedDate,
      timeSlot: selectedSlot,
      transportMode,
      driverName: assignedDriver?.driver_name,
      driverPhone: assignedDriver?.driver_phone,
      pickupTime: preferredPickupTime,
      isOfflineFarmer: false,
    });
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Header */}
      <div className="text-center space-y-2">
        <span className="text-xs font-extrabold uppercase tracking-widest text-emerald-600 bg-emerald-50 px-3 py-1 rounded-full border border-emerald-200">
          Official Procurement Wizard
        </span>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900">
          Smart Mandi Slot Booking Flow
        </h1>
        <p className="text-xs text-slate-500">
          Dynamic path selection determined by your transport requirements
        </p>
      </div>

      {/* Main Step Container */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-xl border border-slate-200">
        {/* STEP 1: Add Crop */}
        {currentStep === 1 && (
          <div className="space-y-4">
            <h3 className="font-extrabold text-base text-slate-900 flex items-center gap-2">
              <Sprout className="w-5 h-5 text-emerald-600" />
              Step 1: Declare Crop & Quantity
            </h3>

            <div className="space-y-3 text-xs">
              <div>
                <label className="font-bold text-slate-700 block mb-1">Crop Variety *</label>
                <select
                  value={cropType}
                  onChange={(e) => setCropType(e.target.value)}
                  className="w-full p-3 bg-slate-50 border border-slate-300 rounded-xl outline-none font-semibold text-xs"
                >
                  <option value="Paddy (Common)">Paddy (Common) - MSP ₹ 2,300/Q</option>
                  <option value="Paddy (Grade A)">Paddy (Grade A) - MSP ₹ 2,320/Q</option>
                  <option value="Wheat (Sharbati)">Wheat (Sharbati) - MSP ₹ 2,425/Q</option>
                  <option value="Wheat (Standard)">Wheat (Standard) - MSP ₹ 2,275/Q</option>
                </select>
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">
                  Expected Harvest Quantity (kg) *
                </label>
                <input
                  type="number"
                  required
                  value={cropQuantityKg}
                  onChange={(e) => setCropQuantityKg(Number(e.target.value))}
                  className="w-full p-3 bg-slate-50 border border-slate-300 rounded-xl outline-none font-bold text-xs"
                />
                <span className="text-[11px] text-slate-400 mt-1 block">
                  = {(cropQuantityKg / 100).toFixed(2)} Quintals
                </span>
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Ready Harvest Date *</label>
                <input
                  type="date"
                  value={harvestDate}
                  onChange={(e) => setHarvestDate(e.target.value)}
                  className="w-full p-3 bg-slate-50 border border-slate-300 rounded-xl outline-none text-xs"
                />
              </div>
            </div>

            <div className="pt-4 flex justify-end">
              <button
                onClick={handleStep1Next}
                className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-md flex items-center gap-1.5"
              >
                <span>Next: Select Procurement Centre</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* STEP 2: Select Procurement Centre */}
        {currentStep === 2 && (
          <div className="space-y-4">
            <h3 className="font-extrabold text-base text-slate-900 flex items-center gap-2">
              <MapPin className="w-5 h-5 text-emerald-600" />
              Step 2: Select Procurement Mandi Yard
            </h3>

            <InteractiveMap
              selectedCentreId={selectedCentre.id}
              onSelectCentre={(c) => setSelectedCentre(c)}
            />

            <div className="pt-4 flex items-center justify-between">
              <button
                onClick={() => setCurrentStep(1)}
                className="px-4 py-2 border border-slate-300 rounded-xl text-xs font-semibold text-slate-700 flex items-center gap-1"
              >
                <ArrowLeft className="w-3.5 h-3.5" /> Back
              </button>
              <button
                onClick={handleStep2Next}
                className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-md flex items-center gap-1.5"
              >
                <span>Next: Choose Transport Mode</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* STEP 3: Transport Selection (DECIDES ENTIRE FLOW - REQUIRED) */}
        {currentStep === 3 && (
          <div className="space-y-6">
            <div>
              <h3 className="font-extrabold text-lg text-slate-900 flex items-center gap-2">
                <Truck className="w-5 h-5 text-emerald-600" />
                Step 3: How will you transport your crop to the Mandi?
              </h3>
              <p className="text-xs text-slate-500 mt-1">
                This choice determines whether you proceed to direct slot booking or automated vehicle pickup allocation.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* Choice A: Self Transport */}
              <label
                onClick={() => setTransportMode('self')}
                className={`p-6 rounded-2xl border-2 cursor-pointer transition-all flex flex-col justify-between ${
                  transportMode === 'self'
                    ? 'border-emerald-600 bg-emerald-50/80 ring-2 ring-emerald-500/20 shadow-md'
                    : 'border-slate-200 hover:bg-slate-50'
                }`}
              >
                <div className="space-y-3">
                  <span className="text-3xl">🚜</span>
                  <div>
                    <h4 className="font-extrabold text-base text-slate-900">
                      Self Transport
                    </h4>
                    <p className="text-xs text-slate-500 mt-1">
                      I will bring my harvested crop to the procurement centre using my own tractor, trolley, or cart.
                    </p>
                  </div>
                </div>

                <div className="mt-4 pt-3 border-t border-slate-200/60 flex items-center justify-between text-xs">
                  <span className="font-bold text-emerald-700">Direct Slot Booking</span>
                  <span className={`w-4 h-4 rounded-full border-2 flex items-center justify-center ${transportMode === 'self' ? 'border-emerald-600 bg-emerald-600 text-white text-[10px]' : 'border-slate-300'}`}>
                    {transportMode === 'self' && '✓'}
                  </span>
                </div>
              </label>

              {/* Choice B: Request Vehicle */}
              <label
                onClick={() => setTransportMode('vehicle')}
                className={`p-6 rounded-2xl border-2 cursor-pointer transition-all flex flex-col justify-between ${
                  transportMode === 'vehicle'
                    ? 'border-blue-600 bg-blue-50/80 ring-2 ring-blue-500/20 shadow-md'
                    : 'border-slate-200 hover:bg-slate-50'
                }`}
              >
                <div className="space-y-3">
                  <span className="text-3xl">🚚</span>
                  <div>
                    <h4 className="font-extrabold text-base text-slate-900">
                      Request Free Vehicle Pickup
                    </h4>
                    <p className="text-xs text-slate-500 mt-1">
                      I need a government-contracted trolley or mini truck to pick up grain directly from my farm or village.
                    </p>
                  </div>
                </div>

                <div className="mt-4 pt-3 border-t border-slate-200/60 flex items-center justify-between text-xs">
                  <span className="font-bold text-blue-700">Vehicle Assigned First</span>
                  <span className={`w-4 h-4 rounded-full border-2 flex items-center justify-center ${transportMode === 'vehicle' ? 'border-blue-600 bg-blue-600 text-white text-[10px]' : 'border-slate-300'}`}>
                    {transportMode === 'vehicle' && '✓'}
                  </span>
                </div>
              </label>
            </div>

            <div className="pt-4 flex items-center justify-between">
              <button
                onClick={() => setCurrentStep(2)}
                className="px-4 py-2 border border-slate-300 rounded-xl text-xs font-semibold text-slate-700 flex items-center gap-1"
              >
                <ArrowLeft className="w-3.5 h-3.5" /> Back
              </button>
              <button
                onClick={handleStep3Next}
                className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-md flex items-center gap-1.5"
              >
                <span>Proceed to {transportMode === 'self' ? 'Slot Calendar' : 'Vehicle Request Form'}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* STEP 4A: Direct Slot Booking (Self Transport) */}
        {currentStep === 41 && (
          <div className="space-y-6">
            <div>
              <span className="text-[10px] font-extrabold uppercase tracking-wider text-emerald-700 bg-emerald-100 px-2.5 py-0.5 rounded-full">
                Self Transport Flow
              </span>
              <h3 className="font-extrabold text-lg text-slate-900 mt-1 flex items-center gap-2">
                <Calendar className="w-5 h-5 text-emerald-600" />
                Step 4A: Select Date & 30-Minute Mandi Slot
              </h3>
              <p className="text-xs text-slate-500">
                Green slots are available. Select your preferred arrival time window.
              </p>
            </div>

            {/* Date Picker Horizontal Bar */}
            <div className="flex gap-2 overflow-x-auto pb-1 no-scrollbar">
              {daysList.map((d) => (
                <button
                  key={d}
                  onClick={() => setSelectedDate(d)}
                  className={`p-3 rounded-xl border text-center text-xs shrink-0 min-w-[100px] transition-all ${
                    selectedDate === d
                      ? 'border-emerald-600 bg-emerald-600 text-white font-bold shadow-md'
                      : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                  }`}
                >
                  <span className="block text-[10px] opacity-80">
                    {new Date(d).toLocaleDateString('en-IN', { weekday: 'short' })}
                  </span>
                  <span className="font-extrabold text-sm">{d.slice(8)}</span>
                </button>
              ))}
            </div>

            {/* Time Slot Grid */}
            <div className="space-y-2">
              <span className="text-xs font-bold text-slate-700 block">Available 30-Minute Slots:</span>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 text-xs">
                {timeSlotsAll.map((slot, idx) => {
                  const isBooked = idx === 3 || idx === 8; // realistic simulation
                  const isSelected = selectedSlot === slot;
                  return (
                    <button
                      key={idx}
                      disabled={isBooked}
                      onClick={() => setSelectedSlot(slot)}
                      className={`p-3 rounded-xl border text-center font-semibold transition-all ${
                        isBooked
                          ? 'bg-rose-50 border-rose-200 text-rose-400 cursor-not-allowed'
                          : isSelected
                          ? 'border-emerald-600 bg-emerald-600 text-white shadow-md'
                          : 'border-emerald-200 bg-emerald-50/50 hover:bg-emerald-100 text-emerald-900'
                      }`}
                    >
                      <span>{slot}</span>
                      <span className="block text-[9px] mt-0.5">
                        {isBooked ? 'Booked' : isSelected ? 'Selected' : 'Available'}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="pt-4 flex items-center justify-between">
              <button
                onClick={() => setCurrentStep(3)}
                className="px-4 py-2 border border-slate-300 rounded-xl text-xs font-semibold text-slate-700 flex items-center gap-1"
              >
                <ArrowLeft className="w-3.5 h-3.5" /> Back
              </button>
              <button
                onClick={handleConfirmSelfSlot}
                className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-lg transition-all flex items-center gap-1.5"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>Confirm Slot Booking</span>
              </button>
            </div>
          </div>
        )}

        {/* STEP 4B: Vehicle Request Form (Vehicle Transport) */}
        {currentStep === 42 && (
          <div className="space-y-6">
            <div>
              <span className="text-[10px] font-extrabold uppercase tracking-wider text-blue-700 bg-blue-100 px-2.5 py-0.5 rounded-full">
                Vehicle Transport Flow
              </span>
              <h3 className="font-extrabold text-lg text-slate-900 mt-1 flex items-center gap-2">
                <Truck className="w-5 h-5 text-blue-600" />
                Step 4B: Submit Vehicle Pickup Request
              </h3>
              <p className="text-xs text-slate-500">
                Provide farm pickup coordinates for automated Haversine vehicle matching.
              </p>
            </div>

            {!assignedDriver && !vehiclePending && (
              <div className="space-y-4 text-xs">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Pickup Village / Area *</label>
                  <input
                    type="text"
                    required
                    value={pickupLocation}
                    onChange={(e) => setPickupLocation(e.target.value)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl outline-none"
                  />
                </div>

                <div>
                  <label className="font-bold text-slate-700 block mb-1">Detailed Pickup Address & Landmark *</label>
                  <textarea
                    rows={2}
                    required
                    value={pickupAddress}
                    onChange={(e) => setPickupAddress(e.target.value)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl outline-none"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="font-bold text-slate-700 block mb-1">Crop Quantity (kg) *</label>
                    <input
                      type="number"
                      readOnly
                      value={cropQuantityKg}
                      className="w-full p-2.5 bg-slate-100 border border-slate-300 rounded-xl font-bold"
                    />
                  </div>

                  <div>
                    <label className="font-bold text-slate-700 block mb-1">Preferred Pickup Window *</label>
                    <select
                      value={preferredPickupTime}
                      onChange={(e) => setPreferredPickupTime(e.target.value)}
                      className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl outline-none font-semibold"
                    >
                      <option value="07:00 AM">07:00 AM - Early Morning</option>
                      <option value="07:30 AM">07:30 AM - Suggested</option>
                      <option value="08:00 AM">08:00 AM - Morning</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="font-bold text-slate-700 block mb-1">Special Bagging Instructions</label>
                  <input
                    type="text"
                    value={specialInstructions}
                    onChange={(e) => setSpecialInstructions(e.target.value)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl outline-none"
                  />
                </div>

                <div className="pt-4 flex items-center justify-between">
                  <button
                    onClick={() => setCurrentStep(3)}
                    className="px-4 py-2 border border-slate-300 rounded-xl font-semibold text-slate-700 flex items-center gap-1"
                  >
                    <ArrowLeft className="w-3.5 h-3.5" /> Back
                  </button>
                  <button
                    onClick={handleSubmitVehicleRequest}
                    className="px-6 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl shadow-md flex items-center gap-1.5"
                  >
                    <span>Submit Vehicle Request & Match Driver</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            )}

            {/* Pending Screen */}
            {vehiclePending && (
              <div className="p-8 text-center space-y-3 bg-blue-50/50 rounded-2xl border border-blue-200">
                <div className="w-12 h-12 rounded-full border-4 border-blue-600 border-t-transparent animate-spin mx-auto" />
                <h4 className="font-extrabold text-base text-slate-900">
                  Triggering Nearest Vehicle Assignment Algorithm...
                </h4>
                <p className="text-xs text-slate-500">
                  Running Haversine distance calculations across {selectedCentre.name} fleet...
                </p>
              </div>
            )}

            {/* Vehicle Assigned Card */}
            {assignedDriver && !vehiclePending && (
              <div className="p-6 bg-emerald-50 rounded-2xl border border-emerald-200 space-y-4">
                <div className="flex items-start justify-between">
                  <div>
                    <span className="text-[10px] font-extrabold uppercase tracking-wider text-emerald-800 bg-emerald-200/80 px-2 py-0.5 rounded">
                      Vehicle Successfully Assigned ✓
                    </span>
                    <h4 className="font-extrabold text-lg text-slate-900 mt-1">
                      {assignedDriver.driver_name}
                    </h4>
                    <p className="text-xs text-slate-600">
                      {assignedDriver.vehicle_type} • Reg: {assignedDriver.registration_number}
                    </p>
                  </div>
                  <a
                    href={`tel:${assignedDriver.driver_phone}`}
                    className="px-3 py-1.5 rounded-lg bg-emerald-600 text-white font-bold text-xs flex items-center gap-1"
                  >
                    <Phone className="w-3.5 h-3.5" /> Call
                  </a>
                </div>

                <div className="grid grid-cols-2 gap-3 text-xs bg-white p-3 rounded-xl border border-emerald-100">
                  <div>
                    <span className="text-slate-400 block text-[10px]">Pickup Scheduled For:</span>
                    <span className="font-bold text-slate-800 text-sm">{preferredPickupTime}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px]">Vehicle Capacity:</span>
                    <span className="font-bold text-slate-800 text-sm">{assignedDriver.capacity_kg} kg</span>
                  </div>
                </div>

                <div className="pt-2 flex justify-end">
                  <button
                    onClick={() => setCurrentStep(52)} // Step 5B
                    className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-md flex items-center gap-1.5"
                  >
                    <span>Proceed to Slot Booking (Step 5B)</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            )}
          </div>
        )}

        {/* STEP 5B: Slot Booking (After Vehicle Assigned) */}
        {currentStep === 52 && (
          <div className="space-y-6">
            <div>
              <span className="text-[10px] font-extrabold uppercase tracking-wider text-blue-700 bg-blue-100 px-2.5 py-0.5 rounded-full">
                Step 5B: Schedule Mandi Arrival
              </span>
              <h3 className="font-extrabold text-lg text-slate-900 mt-1 flex items-center gap-2">
                <Clock className="w-5 h-5 text-blue-600" />
                Select Slot (Locked to ≥ 2 hours after {preferredPickupTime} pickup)
              </h3>
              <p className="text-xs text-slate-500">
                To account for loading and transit time, Mandi appointment slots start from 09:30 AM onwards.
              </p>
            </div>

            {/* Date Picker Bar */}
            <div className="flex gap-2 overflow-x-auto pb-1 no-scrollbar">
              {daysList.map((d) => (
                <button
                  key={d}
                  onClick={() => setSelectedDate(d)}
                  className={`p-3 rounded-xl border text-center text-xs shrink-0 min-w-[100px] transition-all ${
                    selectedDate === d
                      ? 'border-blue-600 bg-blue-600 text-white font-bold shadow-md'
                      : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                  }`}
                >
                  <span className="block text-[10px] opacity-80">
                    {new Date(d).toLocaleDateString('en-IN', { weekday: 'short' })}
                  </span>
                  <span className="font-extrabold text-sm">{d.slice(8)}</span>
                </button>
              ))}
            </div>

            {/* Filtered Slots */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 text-xs">
              {timeSlotsVehicle.map((slot, idx) => (
                <button
                  key={idx}
                  onClick={() => setSelectedSlot(slot)}
                  className={`p-3 rounded-xl border text-center font-semibold transition-all ${
                    selectedSlot === slot
                      ? 'border-blue-600 bg-blue-600 text-white shadow-md'
                      : 'border-blue-200 bg-blue-50/50 hover:bg-blue-100 text-blue-900'
                  }`}
                >
                  <span>{slot}</span>
                </button>
              ))}
            </div>

            <div className="pt-4 flex items-center justify-between">
              <button
                onClick={() => setCurrentStep(42)}
                className="px-4 py-2 border border-slate-300 rounded-xl text-xs font-semibold text-slate-700 flex items-center gap-1"
              >
                <ArrowLeft className="w-3.5 h-3.5" /> Back
              </button>
              <button
                onClick={handleConfirmVehicleSlot}
                className="px-6 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-xl shadow-lg transition-all flex items-center gap-1.5"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>Confirm Slot with Vehicle Pickup</span>
              </button>
            </div>
          </div>
        )}

        {/* STEP 6: Confirmation Screen */}
        {currentStep === 6 && generatedToken && (
          <div className="text-center py-6 space-y-6 animate-scale-in">
            <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center mx-auto shadow-inner">
              <CheckCircle2 className="w-10 h-10 text-emerald-600" />
            </div>

            <div>
              <span className="text-xs font-extrabold text-emerald-600 uppercase tracking-widest">
                Procurement Slot Confirmed
              </span>
              <h2 className="text-3xl font-extrabold text-slate-900 mt-1">
                TOKEN #{generatedToken.token_number} ({generatedToken.token_code})
              </h2>
              <p className="text-xs text-slate-500 mt-1">
                {selectedCentre.name} • {selectedDate} at {selectedSlot}
              </p>
            </div>

            {/* Summary Details Card */}
            <div className="max-w-md mx-auto p-4 bg-slate-50 rounded-2xl border border-slate-200 text-xs text-left space-y-2">
              <div className="flex justify-between">
                <span className="text-slate-500">Transport Method:</span>
                <span className="font-bold text-slate-900 capitalize">
                  {transportMode === 'vehicle' ? 'Government Vehicle Pickup' : 'Self Transport'}
                </span>
              </div>
              {transportMode === 'vehicle' && assignedDriver && (
                <>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Assigned Driver:</span>
                    <span className="font-bold text-slate-900">{assignedDriver.driver_name}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Driver Phone:</span>
                    <span className="font-bold text-slate-900">{assignedDriver.driver_phone}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Pickup Time:</span>
                    <span className="font-bold text-slate-900">{preferredPickupTime}</span>
                  </div>
                </>
              )}
              <div className="flex justify-between">
                <span className="text-slate-500">Crop & Weight:</span>
                <span className="font-bold text-slate-900">{cropType} ({cropQuantityKg} kg)</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">SMS Notifications:</span>
                <span className="font-bold text-emerald-600">Dispatched via MSG91 ✓</span>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
              <button
                onClick={handleDownloadPdf}
                className="flex items-center gap-1.5 px-5 py-3 bg-slate-900 hover:bg-black text-white font-bold text-xs rounded-xl shadow-md transition-all"
              >
                <FileDown className="w-4 h-4" />
                Download PDF Token Slip
              </button>

              {transportMode === 'vehicle' ? (
                <button
                  onClick={() => navigate('/farmer/vehicle-tracking')}
                  className="flex items-center gap-1.5 px-5 py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-md transition-all"
                >
                  <MapPin className="w-4 h-4" />
                  Track Vehicle Live
                </button>
              ) : (
                <button
                  onClick={() => navigate('/farmer/transport')}
                  className="flex items-center gap-1.5 px-5 py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-md transition-all"
                >
                  <Navigation className="w-4 h-4" />
                  View Mandi Directions (OSRM)
                </button>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
