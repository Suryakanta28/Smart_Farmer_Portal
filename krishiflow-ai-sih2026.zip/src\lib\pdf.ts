// PDF Generation for Token Slips & Payment Receipts
// KRISHIFLOW-AI - Smart India Hackathon 2026

import jsPDF from 'jspdf';
import QRCode from 'qrcode';

export interface TokenPdfData {
  tokenCode: string;
  tokenNumber: number;
  farmerName: string;
  farmerPhone?: string;
  village: string;
  district: string;
  cropType: string;
  cropQuantityKg: number;
  centreName: string;
  centreAddress: string;
  date: string;
  timeSlot: string;
  transportMode: 'self' | 'vehicle';
  driverName?: string;
  driverPhone?: string;
  pickupTime?: string;
  isOfflineFarmer?: boolean;
}

export async function generateTokenPdf(data: TokenPdfData): Promise<void> {
  const doc = new jsPDF();
  const qrDataUrl = await QRCode.toDataURL(`KRISHIFLOW-TOKEN:${data.tokenCode}|FARMER:${data.farmerName}|DATE:${data.date}|CENTRE:${data.centreName}`);

  // Header Banner
  doc.setFillColor(22, 163, 74); // Green
  doc.rect(0, 0, 210, 30, 'F');

  doc.setTextColor(255, 255, 255);
  doc.setFontSize(18);
  doc.setFont('helvetica', 'bold');
  doc.text('KRISHIFLOW-AI | FARMER PROCUREMENT PLATFORM', 15, 14);
  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  doc.text('Government of India & State Agriculture Marketing Board • SIH 2026 (Problem ID: SIH26032)', 15, 22);

  // Token Badge Card
  doc.setFillColor(240, 253, 244);
  doc.setDrawColor(22, 163, 74);
  doc.roundedRect(15, 38, 180, 34, 3, 3, 'FD');

  doc.setTextColor(21, 128, 61);
  doc.setFontSize(12);
  doc.setFont('helvetica', 'bold');
  doc.text(data.isOfflineFarmer ? 'OFFLINE FARMER ASSISTED PROCUREMENT SLIP' : 'OFFICIAL PROCUREMENT GATE PASS TOKEN', 22, 47);

  doc.setFontSize(22);
  doc.setTextColor(15, 23, 42);
  doc.text(`TOKEN: ${data.tokenCode}`, 22, 60);

  doc.setFontSize(12);
  doc.setTextColor(225, 29, 72);
  doc.text(`QUEUE SEQUENCE: #${data.tokenNumber}`, 120, 60);

  // QR Code
  doc.addImage(qrDataUrl, 'PNG', 145, 78, 50, 50);

  // Details
  doc.setTextColor(15, 23, 42);
  doc.setFontSize(11);
  doc.setFont('helvetica', 'bold');
  doc.text('1. FARMER INFORMATION', 15, 82);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(10);
  doc.text(`Name: ${data.farmerName}`, 20, 90);
  doc.text(`Contact: ${data.farmerPhone || 'Recorded via Society Alternate'}`, 20, 97);
  doc.text(`Village / District: ${data.village}, ${data.district}`, 20, 104);
  doc.text(`Crop & Expected Weight: ${data.cropType} - ${data.cropQuantityKg} kg`, 20, 111);

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.text('2. PROCUREMENT CENTRE & SLOT SCHEDULE', 15, 124);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(10);
  doc.text(`Centre: ${data.centreName}`, 20, 132);
  doc.text(`Address: ${data.centreAddress}`, 20, 139);
  doc.text(`Appointment Date: ${data.date}`, 20, 146);
  doc.text(`Time Slot: ${data.timeSlot}`, 20, 153);

  // Transport Details Box
  doc.setFillColor(data.transportMode === 'vehicle' ? 238 : 241, 242, 255);
  doc.roundedRect(15, 162, 180, 42, 2, 2, 'F');
  
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.setTextColor(30, 58, 138);
  doc.text(`3. LOGISTICS MODE: ${data.transportMode === 'vehicle' ? 'FREE GOVERNMENT VEHICLE PICKUP' : 'SELF TRANSPORT'}`, 20, 172);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(10);
  doc.setTextColor(15, 23, 42);
  if (data.transportMode === 'vehicle') {
    doc.text(`Assigned Driver: ${data.driverName || 'Suresh Kumar Mohapatra'} (${data.driverPhone || '+91-9876543210'})`, 20, 182);
    doc.text(`Vehicle Scheduled Pickup Time: ${data.pickupTime || '07:30 AM'} from farmer village`, 20, 190);
    doc.text(`Notice: Keep crop bagged in standard 50kg jute bags ready for weighing.`, 20, 197);
  } else {
    doc.text(`Instructions: Arrive at mandi yard 15 minutes before slot with this token slip.`, 20, 182);
    doc.text(`Dedicated lane parking available at Mandi Bay 4. Bring Aadhaar copy.`, 20, 190);
  }

  // Footer Instructions
  doc.setDrawColor(203, 213, 225);
  doc.line(15, 215, 195, 215);

  doc.setFontSize(9);
  doc.setTextColor(100, 116, 139);
  doc.text('Important Instructions:', 15, 224);
  doc.text('• Present this QR code token at the Mandi Security Gate for instantaneous barcode scan.', 15, 230);
  doc.text('• Digital weighing and moisture analysis will determine Grade A/B/C pricing automatically.', 15, 236);
  doc.text('• Direct Benefit Transfer (DBT) payment will be credited directly to your Aadhaar-linked bank account.', 15, 242);
  doc.text('• Helpline Toll-Free: 1800-180-2026 | Powered by KrishiFlow-AI (SIH 2026)', 15, 252);

  doc.save(`Token-${data.tokenCode}.pdf`);
}

export interface PaymentReceiptPdfData {
  receiptId: string;
  farmerName: string;
  village: string;
  cropType: string;
  grossWeightKg: number;
  tareWeightKg: number;
  netWeightKg: number;
  moisturePercentage: number;
  qualityGrade: string;
  mspRatePerQuintal: number;
  totalAmount: number;
  pfmsTxnId: string;
  bankRef: string;
  date: string;
}

export async function generatePaymentReceiptPdf(data: PaymentReceiptPdfData): Promise<void> {
  const doc = new jsPDF();
  const qrDataUrl = await QRCode.toDataURL(`RECEIPT:${data.receiptId}|AMT:${data.totalAmount}|PFMS:${data.pfmsTxnId}`);

  // Header Banner
  doc.setFillColor(37, 99, 235); // Blue
  doc.rect(0, 0, 210, 30, 'F');

  doc.setTextColor(255, 255, 255);
  doc.setFontSize(18);
  doc.setFont('helvetica', 'bold');
  doc.text('KRISHIFLOW-AI | DBT PAYMENT RECEIPT', 15, 14);
  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  doc.text('Public Financial Management System (PFMS) Direct Benefit Settlement', 15, 22);

  // Receipt Card
  doc.setFillColor(239, 246, 255);
  doc.roundedRect(15, 38, 180, 30, 3, 3, 'F');
  doc.setTextColor(30, 58, 138);
  doc.setFontSize(12);
  doc.setFont('helvetica', 'bold');
  doc.text(`RECEIPT NO: ${data.receiptId}`, 22, 48);
  doc.text(`PFMS TXN ID: ${data.pfmsTxnId}`, 22, 58);
  doc.setTextColor(22, 163, 74);
  doc.setFontSize(16);
  doc.text(`₹ ${data.totalAmount.toLocaleString('en-IN')}`, 135, 54);

  // QR
  doc.addImage(qrDataUrl, 'PNG', 150, 75, 45, 45);

  // Table
  doc.setTextColor(15, 23, 42);
  doc.setFontSize(11);
  doc.setFont('helvetica', 'bold');
  doc.text('Procurement & Settlement Breakdown', 15, 80);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(10);
  let y = 92;
  const items = [
    ['Beneficiary Farmer', data.farmerName],
    ['Village / Mandi Yard', data.village],
    ['Crop Purchased', data.cropType],
    ['Gross Weighbridge Reading', `${data.grossWeightKg} kg`],
    ['Tare (Vehicle / Bag) Weight', `${data.tareWeightKg} kg`],
    ['Net Procurement Weight', `${data.netWeightKg} kg (${(data.netWeightKg / 100).toFixed(2)} Quintals)`],
    ['Moisture Content Assessed', `${data.moisturePercentage}% (Standard: <14%)`],
    ['Certified Quality Grade', data.qualityGrade],
    ['Approved MSP Rate', `₹ ${data.mspRatePerQuintal} / Quintal`],
    ['Bank Reference / UTR', data.bankRef],
    ['Settlement Date', data.date],
  ];

  items.forEach(([label, value]) => {
    doc.text(label, 20, y);
    doc.text(value, 95, y);
    y += 8;
  });

  doc.setDrawColor(203, 213, 225);
  doc.line(15, y + 5, 195, y + 5);

  doc.setFontSize(9);
  doc.setTextColor(100, 116, 139);
  doc.text('Status: DBT DIRECT BANK TRANSFER CREDITED • Digitally signed by KrishiFlow-AI Mandi Server', 15, y + 16);

  doc.save(`Receipt-${data.receiptId}.pdf`);
}
