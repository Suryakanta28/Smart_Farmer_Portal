// My Crops Management Page (Full CRUD Operations)
// KRISHIFLOW-AI - Smart India Hackathon 2026 (Problem ID: SIH26032)

import React, { useState, useEffect } from 'react';
import { Plus, Sprout, Edit2, Trash2, Calendar, Scale, CheckCircle2, X } from 'lucide-react';
import { db, Crop } from '../../lib/db';
import { useAuth } from '../../context/AuthContext';

export const MyCrops: React.FC = () => {
  const { user } = useAuth();
  const [crops, setCrops] = useState<Crop[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingCrop, setEditingCrop] = useState<Crop | null>(null);

  const [formData, setFormData] = useState({
    crop_type: 'Paddy (Common)',
    expected_quantity_kg: 2500,
    harvest_date: new Date().toISOString().split('T')[0],
  });

  const loadCrops = () => {
    const all = db.getCollection<Crop>('crops');
    setCrops(all);
  };

  useEffect(() => {
    loadCrops();
    const unsub = db.subscribe('table:crops', () => loadCrops());
    return () => unsub();
  }, []);

  const handleOpenAdd = () => {
    setEditingCrop(null);
    setFormData({
      crop_type: 'Paddy (Common)',
      expected_quantity_kg: 2500,
      harvest_date: new Date().toISOString().split('T')[0],
    });
    setIsModalOpen(true);
  };

  const handleOpenEdit = (crop: Crop) => {
    setEditingCrop(crop);
    setFormData({
      crop_type: crop.crop_type,
      expected_quantity_kg: crop.expected_quantity_kg,
      harvest_date: crop.harvest_date,
    });
    setIsModalOpen(true);
  };

  const handleDelete = (id: string) => {
    if (confirm('Are you sure you want to delete this registered crop?')) {
      db.deleteCrop(id);
      loadCrops();
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingCrop) {
      db.updateCrop(editingCrop.id, {
        crop_type: formData.crop_type,
        expected_quantity_kg: Number(formData.expected_quantity_kg),
        harvest_date: formData.harvest_date,
      });
    } else {
      db.addCrop({
        farmer_id: 'far-01',
        crop_type: formData.crop_type,
        expected_quantity_kg: Number(formData.expected_quantity_kg),
        harvest_date: formData.harvest_date,
      });
    }
    setIsModalOpen(false);
    loadCrops();
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900">
            My Registered Crops
          </h2>
          <p className="text-xs text-slate-500">
            Declare your expected harvest yields to automatically enable Mandi slot allocations
          </p>
        </div>

        <button
          onClick={handleOpenAdd}
          className="flex items-center justify-center gap-1.5 px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-md transition-all self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          Add Crop Declaration
        </button>
      </div>

      {/* Crops List */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {crops.map((crop) => (
          <div
            key={crop.id}
            className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm hover:shadow-md transition-shadow flex flex-col justify-between"
          >
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center">
                  <Sprout className="w-5 h-5" />
                </div>
                <span className="text-[10px] font-bold uppercase tracking-wider px-2.5 py-0.5 rounded-full bg-slate-100 text-slate-700">
                  {crop.status.replace('_', ' ')}
                </span>
              </div>

              <div>
                <h3 className="font-extrabold text-base text-slate-900">{crop.crop_type}</h3>
                <span className="text-xs text-slate-400 font-mono">ID: {crop.id}</span>
              </div>

              <div className="grid grid-cols-2 gap-2 text-xs bg-slate-50 p-2.5 rounded-xl">
                <div>
                  <span className="text-[10px] text-slate-400 block">Expected Weight</span>
                  <span className="font-bold text-slate-800">{crop.expected_quantity_kg} kg</span>
                  <span className="text-[10px] text-emerald-600 block">
                    ({(crop.expected_quantity_kg / 100).toFixed(1)} Quintals)
                  </span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-400 block">Harvest Date</span>
                  <span className="font-bold text-slate-800">{crop.harvest_date}</span>
                </div>
              </div>
            </div>

            <div className="pt-4 mt-4 border-t border-slate-100 flex items-center justify-between">
              <div className="flex gap-2">
                <button
                  onClick={() => handleOpenEdit(crop)}
                  className="p-1.5 rounded-lg text-slate-600 hover:text-emerald-700 hover:bg-emerald-50 text-xs font-semibold flex items-center gap-1"
                >
                  <Edit2 className="w-3.5 h-3.5" />
                  Edit
                </button>
                <button
                  onClick={() => handleDelete(crop.id)}
                  className="p-1.5 rounded-lg text-slate-600 hover:text-rose-600 hover:bg-rose-50 text-xs font-semibold flex items-center gap-1"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  Delete
                </button>
              </div>

              <a
                href="/farmer/procurement"
                className="text-xs font-bold text-emerald-600 hover:underline"
              >
                Procure Crop →
              </a>
            </div>
          </div>
        ))}
      </div>

      {/* Add / Edit Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fade-in">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-md p-6 overflow-hidden">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="font-extrabold text-base text-slate-900">
                {editingCrop ? 'Edit Crop Declaration' : 'Declare New Harvest Batch'}
              </h3>
              <button
                onClick={() => setIsModalOpen(false)}
                className="text-slate-400 hover:text-slate-700 p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4 pt-4 text-xs">
              <div>
                <label className="font-bold text-slate-700 block mb-1">Crop Type *</label>
                <select
                  value={formData.crop_type}
                  onChange={(e) => setFormData({ ...formData, crop_type: e.target.value })}
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl outline-none font-semibold"
                >
                  <option value="Paddy (Common)">Paddy (Common) - MSP ₹ 2,300/Q</option>
                  <option value="Paddy (Grade A)">Paddy (Grade A) - MSP ₹ 2,320/Q</option>
                  <option value="Wheat (Sharbati)">Wheat (Sharbati) - MSP ₹ 2,425/Q</option>
                  <option value="Wheat (Standard)">Wheat (Standard) - MSP ₹ 2,275/Q</option>
                  <option value="Maize">Maize - MSP ₹ 2,225/Q</option>
                </select>
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">
                  Expected Crop Quantity (in Kilograms) *
                </label>
                <input
                  type="number"
                  required
                  value={formData.expected_quantity_kg}
                  onChange={(e) => setFormData({ ...formData, expected_quantity_kg: Number(e.target.value) })}
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl outline-none font-bold"
                />
                <span className="text-[10px] text-slate-400 mt-0.5 block">
                  = {(formData.expected_quantity_kg / 100).toFixed(2)} Quintals
                </span>
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Expected Harvest Date *</label>
                <input
                  type="date"
                  required
                  value={formData.harvest_date}
                  onChange={(e) => setFormData({ ...formData, harvest_date: e.target.value })}
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl outline-none"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 border border-slate-300 rounded-xl font-semibold text-slate-700"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl shadow-md"
                >
                  {editingCrop ? 'Update Crop' : 'Save Declaration'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
